// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "RawPair",
    platforms: [.macOS(.v15)],
    products: [
        .executable(name: "RawSeek", targets: ["RawPair"])
    ],
    targets: [
        .target(name: "RawPairCore"),
        .executableTarget(name: "RawPair", dependencies: ["RawPairCore"]),
        .testTarget(name: "RawPairTests", dependencies: ["RawPairCore"])
    ]
)
