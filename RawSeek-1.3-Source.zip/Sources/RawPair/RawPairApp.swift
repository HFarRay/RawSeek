import AppKit
import ServiceManagement
import SwiftUI
import UniformTypeIdentifiers
import QuickLookThumbnailing
import RawPairCore

@main
struct RawPairApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @AppStorage("showTaskbarIcon") private var showTaskbarIcon = false

    var body: some Scene {
        WindowGroup("RawSeek", id: "main") {
            MatcherView()
                .frame(minWidth: 820, minHeight: 650)
        }
        .windowStyle(.hiddenTitleBar)
        .defaultSize(width: 980, height: 760)

        MenuBarExtra("RawSeek", systemImage: "camera.aperture", isInserted: $showTaskbarIcon) {
            TaskbarMenu()
        }
        .menuBarExtraStyle(.menu)
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
    }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows: Bool) -> Bool {
        if !hasVisibleWindows {
            NSApp.windows.first(where: { $0.canBecomeKey })?.makeKeyAndOrderFront(nil)
        }
        NSApp.activate(ignoringOtherApps: true)
        return true
    }

}

private struct TaskbarMenu: View {
    @Environment(\.openWindow) private var openWindow
    @AppStorage("appLanguage") private var appLanguage = "zh"

    private func text(_ chinese: String, _ english: String) -> String {
        appLanguage == "en" ? english : chinese
    }

    var body: some View {
        Button(text("打开 RawSeek", "Open RawSeek")) {
            if let window = NSApp.windows.first(where: { $0.canBecomeKey }) {
                NSApp.activate(ignoringOtherApps: true)
                window.makeKeyAndOrderFront(nil)
            } else {
                openWindow(id: "main")
            }
        }
        Button(text("退出 RawSeek", "Quit RawSeek")) {
            NSApp.terminate(nil)
        }
    }
}

struct MatcherView: View {
    @Environment(\.colorScheme) private var colorScheme
    @AppStorage("searchBookmark") private var searchBookmark = Data()
    @AppStorage("outputBookmark") private var outputBookmark = Data()
    @AppStorage("launchAtLogin") private var launchAtLogin = false
    @AppStorage("showTaskbarIcon") private var showTaskbarIcon = false
    @AppStorage("appearanceMode") private var appearanceModeRawValue = AppearanceMode.system.rawValue
    @AppStorage("appLanguage") private var appLanguage = "zh"

    @State private var searchFolder: URL?
    @State private var outputFolder: URL?
    @State private var droppedJPEGs: [URL] = []
    @State private var results: [MatchResult] = []
    @State private var isTargeted = false
    @State private var isSearching = false
    @State private var isCopying = false
    @State private var copyProgress = 0.0
    @State private var copyStatus = ""
    @State private var isImportingSearch = false
    @State private var activeSearchID = UUID()
    @State private var activeSearchWorker: Task<[MatchResult], Error>?
    @State private var searchTimeoutTask: Task<Void, Never>?
    @State private var message: String?
    @State private var isShowingAbout = false
    @State private var isShowingSettings = false

    private enum AppearanceMode: String, CaseIterable, Identifiable {
        case system = "跟随系统"
        case light = "浅色"
        case dark = "深色"

        var id: String { rawValue }
        var colorScheme: ColorScheme? {
            switch self {
            case .system: nil
            case .light: .light
            case .dark: .dark
            }
        }
    }

    private var appearanceMode: AppearanceMode {
        AppearanceMode(rawValue: appearanceModeRawValue) ?? .system
    }

    private var isEnglish: Bool { appLanguage == "en" }

    private func text(_ chinese: String, _ english: String) -> String {
        isEnglish ? english : chinese
    }

    private func appearanceLabel(_ mode: AppearanceMode) -> String {
        switch mode {
        case .system: text("跟随系统", "System")
        case .light: text("浅色", "Light")
        case .dark: text("深色", "Dark")
        }
    }

    private var foundCount: Int { results.filter { $0.rawURL != nil }.count }

    var body: some View {
        ZStack {
            Color(nsColor: .windowBackgroundColor).ignoresSafeArea()
            VStack(spacing: 0) {
                header
                ScrollView {
                    VStack(alignment: .leading, spacing: 24) {
                        dropSection
                        resultsSection
                    }
                    .padding(.horizontal, 34)
                    .padding(.top, 24)
                    .padding(.bottom, 22)
                }
                footer
            }
        }
        .tint(RawSeekPalette.action)
        .preferredColorScheme(appearanceMode.colorScheme)
        .onAppear {
            applyAppearance()
            DispatchQueue.main.async {
                NSApp.activate(ignoringOtherApps: true)
                NSApp.windows.first(where: { $0.canBecomeKey })?.makeKeyAndOrderFront(nil)
            }
            let savedSearchBookmark = searchBookmark
            let savedOutputBookmark = outputBookmark
            Task {
                let restoredFolders = await Task.detached(priority: .utility) {
                    (
                        FolderBookmarkResolver.resolve(savedSearchBookmark),
                        FolderBookmarkResolver.resolve(savedOutputBookmark)
                    )
                }.value
                if searchFolder == nil { searchFolder = restoredFolders.0 }
                if outputFolder == nil { outputFolder = restoredFolders.1 }
            }
        }
        .fileImporter(isPresented: $isImportingSearch, allowedContentTypes: [.folder]) { saveSearchFolder($0) }
        .onChange(of: launchAtLogin) { _, enabled in updateLoginItem(enabled) }
        .onChange(of: appearanceModeRawValue) { _, _ in applyAppearance() }
        .sheet(isPresented: $isShowingAbout) { AboutView(language: $appLanguage) }
    }

    private var header: some View {
        HStack(spacing: 12) {
            RawSeekIcon().frame(width: 42, height: 42)
            VStack(alignment: .leading, spacing: 2) {
                Text("RawSeek").font(.system(size: 17, weight: .semibold))
                Text(text("JPG 与相机原始文件配对", "JPG & camera RAW pairing")).font(.system(size: 11)).foregroundStyle(.secondary)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 2) {
                HStack(spacing: 5) {
                    Button { appLanguage = "zh" } label: {
                        Text("🇨🇳").font(.system(size: 22)).frame(width: 36, height: 30)
                            .background(appLanguage == "zh" ? RawSeekPalette.action.opacity(0.12) : .clear, in: Capsule())
                    }
                    .buttonStyle(.plain)
                    .help(text("中文", "Chinese"))
                    .accessibilityLabel(text("中文", "Chinese"))
                    Button { appLanguage = "en" } label: {
                        Text("🇺🇸").font(.system(size: 22)).frame(width: 36, height: 30)
                            .background(appLanguage == "en" ? RawSeekPalette.action.opacity(0.12) : .clear, in: Capsule())
                    }
                    .buttonStyle(.plain)
                    .help("English")
                    .accessibilityLabel("English")
                }
                Text("The way to switch language inspired by Smartisan🔨")
                    .font(.system(size: 8))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            settingsMenu
        }
        .padding(.horizontal, 30)
        .padding(.vertical, 18)
        .background(.regularMaterial)
        .overlay(alignment: .bottom) { Rectangle().fill(.black.opacity(0.06)).frame(height: 1) }
    }

    private var settingsMenu: some View {
        Button { isShowingSettings.toggle() } label: {
            HStack(spacing: 4) {
                Image(systemName: "gearshape")
                Image(systemName: "chevron.down").font(.system(size: 9, weight: .semibold))
            }
            .font(.system(size: 13, weight: .medium))
            .padding(.horizontal, 9)
            .frame(width: 48, height: 32)
            .background(Color.primary.opacity(0.07), in: Capsule())
            .fixedSize()
        }
        .buttonStyle(.plain)
        .popover(isPresented: $isShowingSettings, arrowEdge: .top) {
            VStack(alignment: .leading, spacing: 14) {
                Toggle(text("登录时启动", "Launch at Login"), isOn: $launchAtLogin)
                Toggle(text("显示任务栏图标", "Show Taskbar Icon"), isOn: $showTaskbarIcon)
                Divider()
                VStack(alignment: .leading, spacing: 8) {
                    Text(text("外观", "Appearance")).font(.system(size: 12, weight: .medium)).foregroundStyle(.secondary)
                    Picker(text("外观", "Appearance"), selection: $appearanceModeRawValue) {
                        ForEach(AppearanceMode.allCases) { mode in
                            Text(appearanceLabel(mode)).tag(mode.rawValue)
                        }
                    }
                    .labelsHidden()
                    .pickerStyle(.segmented)
                }
                Divider()
                Button { isShowingAbout = true; isShowingSettings = false } label: {
                    Label(text("关于 RawSeek", "About RawSeek"), systemImage: "info.circle")
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .buttonStyle(.plain)
            }
            .padding(16)
            .frame(width: 270)
        }
        .help(text("设置", "Settings"))
    }

    private var dropSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                Text(text("导入照片", "Import Photos")).font(.system(size: 14, weight: .semibold))
                Spacer()
                if !droppedJPEGs.isEmpty {
                    Button(text("清除", "Clear")) { droppedJPEGs.removeAll(); results.removeAll() }
                        .buttonStyle(.link).font(.system(size: 12))
                        .disabled(isCopying)
                }
            }
            VStack(spacing: 12) {
                Image(systemName: droppedJPEGs.isEmpty ? "photo.badge.plus" : "checkmark.circle.fill")
                    .font(.system(size: 26, weight: .light))
                    .foregroundStyle(droppedJPEGs.isEmpty ? Color.secondary : Color(red: 0.10, green: 0.58, blue: 0.43))
                Text(droppedJPEGs.isEmpty ? text("将 JPG 照片拖到这里", "Drop JPG photos here") : text("已添加 \(droppedJPEGs.count) 张 JPG 照片", "\(droppedJPEGs.count) JPG photos added"))
                    .font(.system(size: 15, weight: .medium))
                Text(text("也可以点按选择多个文件", "Or click to choose multiple files"))
                    .font(.system(size: 12)).foregroundStyle(.secondary)
                Button {
                    NSOpenPanel.openJPEGs(language: appLanguage) { droppedJPEGs = uniqueURLs(droppedJPEGs + $0); results = [] }
                } label: {
                    Label(text("选择 JPG", "Choose JPGs"), systemImage: "plus")
                        .font(.system(size: 12, weight: .medium))
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                .disabled(isCopying)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 164)
            .background(Color.primary.opacity(isTargeted ? 0.085 : 0.045), in: RoundedRectangle(cornerRadius: 18))
            .overlay {
                RoundedRectangle(cornerRadius: 18)
                    .strokeBorder(isTargeted ? RawSeekPalette.accent(for: colorScheme).opacity(0.72) : Color.black.opacity(0.10), style: StrokeStyle(lineWidth: 1, dash: [6, 5]))
            }
            .onDrop(of: [.fileURL], isTargeted: $isTargeted, perform: acceptDrop)
            if !droppedJPEGs.isEmpty {
                ScrollView(.horizontal) {
                    LazyHStack(alignment: .top, spacing: 10) {
                        ForEach(droppedJPEGs, id: \.self) { url in
                            ImportedJPEGPreview(url: url)
                        }
                    }
                    .padding(.vertical, 1)
                }
                .frame(height: 94)
            }
        }
    }

    private func folderTile(title: String, symbol: String, url: URL?, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 11) {
                Image(systemName: symbol).font(.system(size: 15)).foregroundStyle(RawSeekPalette.accent(for: colorScheme))
                    .frame(width: 34, height: 34).background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 10))
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.system(size: 11)).foregroundStyle(.secondary)
                    Text(url?.lastPathComponent ?? text("选择文件夹…", "Choose Folder…"))
                        .font(.system(size: 12, weight: .medium)).lineLimit(1).foregroundStyle(.primary)
                }
                Spacer(minLength: 2)
                Image(systemName: "chevron.right").font(.system(size: 10, weight: .semibold)).foregroundStyle(.tertiary)
            }
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.primary.opacity(0.045), in: RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(.black.opacity(0.07)))
            .modifier(GlassSurface(shape: RoundedRectangle(cornerRadius: 14)))
        }
        .buttonStyle(.plain)
        .help(url?.path ?? text("选择文件夹", "Choose folder"))
    }

    private var resultsSection: some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack {
                Text(text("匹配结果", "Match Results")).font(.system(size: 14, weight: .semibold))
                if !results.isEmpty {
                    Text(text("\(foundCount) / \(results.count) 已找到", "\(foundCount) / \(results.count) found")).font(.system(size: 11)).foregroundStyle(.secondary)
                }
                Spacer()
            }
            HStack(spacing: 12) {
                folderTile(title: text("RAW 搜索目录", "RAW Search Folder"), symbol: "folder", url: searchFolder) { isImportingSearch = true }
                    .overlay(alignment: .bottom) {
                        if isSearching {
                            SearchTaskbarProgressBar(colorScheme: colorScheme)
                                .padding(.horizontal, 12)
                                .padding(.bottom, 5)
                                .allowsHitTesting(false)
                        }
                    }
                Button {
                    if isSearching { stopSearch() }
                    else { search() }
                } label: {
                    Label(
                        isSearching ? text("停止搜索", "Stop Search") : text("搜索 RAW", "Search RAW"),
                        systemImage: isSearching ? "stop.fill" : "magnifyingglass"
                    )
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(isSearching ? Color.white : RawSeekPalette.searchForeground(for: colorScheme))
                        .frame(width: 148, height: 60)
                }
                .buttonStyle(.plain)
                .background(
                    isSearching ? Color(red: 0.78, green: 0.16, blue: 0.16) : RawSeekPalette.searchBackground(for: colorScheme),
                    in: RoundedRectangle(cornerRadius: 14)
                )
                .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(isSearching ? Color.red.opacity(0.75) : RawSeekPalette.accent(for: colorScheme).opacity(0.38)))
                .modifier(GlassSurface(shape: RoundedRectangle(cornerRadius: 14)))
                .disabled(isCopying || (!isSearching && (droppedJPEGs.isEmpty || searchFolder == nil)))
            }
            if results.isEmpty {
                HStack(spacing: 10) {
                    Image(systemName: "rectangle.stack").font(.system(size: 15)).foregroundStyle(.tertiary)
                    Text(text("搜索后，匹配文件会显示在这里", "Matched files will appear here after searching")).font(.system(size: 12)).foregroundStyle(.secondary)
                    Spacer()
                }
                .padding(.horizontal, 14).frame(height: 54)
                .background(Color.primary.opacity(0.045), in: RoundedRectangle(cornerRadius: 12))
            } else {
                VStack(spacing: 0) {
                    ForEach(results) { result in resultRow(result) }
                }
                .background(Color.primary.opacity(0.045), in: RoundedRectangle(cornerRadius: 12))
                .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(.black.opacity(0.06)))
            }
            if let message { Text(message).font(.system(size: 11)).foregroundStyle(.secondary) }
        }
    }

    private func resultRow(_ result: MatchResult) -> some View {
        HStack(spacing: 10) {
            Image(systemName: result.rawURL == nil ? "xmark.circle" : "checkmark.circle.fill")
                .foregroundStyle(result.rawURL == nil ? Color.orange : Color.green)
            VStack(alignment: .leading, spacing: 3) {
                Text(result.jpegURL.lastPathComponent).font(.system(size: 12, weight: .medium)).lineLimit(1)
                Text(result.rawURL?.lastPathComponent ?? text("未找到 RAW 文件", "RAW file not found")).font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer()
            if let raw = result.rawURL {
                Button { NSWorkspace.shared.activateFileViewerSelecting([raw]) } label: {
                    Image(systemName: "arrow.up.forward.app").frame(width: 26, height: 26)
                }.buttonStyle(.borderless).help(text("在访达中显示", "Show in Finder"))
            }
        }
        .padding(.horizontal, 12).frame(height: 46)
        .overlay(alignment: .bottom) { Rectangle().fill(.black.opacity(0.045)).frame(height: 1) }
    }

    private var footer: some View {
        VStack(spacing: 10) {
            if isCopying {
                VStack(alignment: .leading, spacing: 5) {
                    HStack {
                        Text(copyStatus).font(.system(size: 11)).foregroundStyle(.secondary)
                        Spacer()
                        Text("\(Int(copyProgress * 100))%")
                            .font(.system(size: 10, weight: .medium, design: .monospaced))
                            .foregroundStyle(.secondary)
                    }
                    ProgressView(value: copyProgress)
                        .tint(RawSeekPalette.accent(for: colorScheme))
                }
            } else {
                HStack(spacing: 7) {
                    Circle().fill(results.isEmpty ? Color.gray.opacity(0.42) : Color.green).frame(width: 7, height: 7)
                    Text(footerStatus).font(.system(size: 11)).foregroundStyle(.secondary)
                    Spacer()
                }
            }
            HStack(spacing: 12) {
                Button {
                    revealFound()
                } label: {
                    Label(text("在访达中显示", "Show in Finder"), systemImage: "folder")
                        .font(.system(size: 14, weight: .semibold))
                        .frame(maxWidth: .infinity, minHeight: 48)
                }
                .buttonStyle(.borderedProminent)
                .tint(RawSeekPalette.action)
                .disabled(results.isEmpty || foundCount == 0)
                Button {
                    NSOpenPanel.openFolder(startingAt: outputFolder, language: appLanguage) { folder in
                        outputFolder = folder
                        let bookmark = (try? folder.bookmarkData(options: .withSecurityScope, includingResourceValuesForKeys: nil, relativeTo: nil)) ?? Data()
                        outputBookmark = bookmark
                        copyFound(to: folder)
                    }
                } label: {
                    Label(
                        isCopying ? text("正在复制…", "Copying…") : text("复制到文件夹…", "Copy to Folder…"),
                        systemImage: "doc.on.doc"
                    )
                        .font(.system(size: 14, weight: .semibold))
                        .frame(maxWidth: .infinity, minHeight: 48)
                }
                .buttonStyle(.bordered)
                .disabled(results.isEmpty || foundCount == 0 || isCopying)
            }
        }
        .padding(.horizontal, 30).padding(.vertical, 12)
        .background(.regularMaterial)
        .overlay(alignment: .top) { Rectangle().fill(.black.opacity(0.06)).frame(height: 1) }
    }

    private var footerStatus: String {
        if !results.isEmpty { return text("已匹配 \(foundCount) / \(results.count) 张照片", "Matched \(foundCount) of \(results.count) photos") }
        return droppedJPEGs.isEmpty ? text("等待导入 JPG", "Waiting for JPGs") : text("已导入 \(droppedJPEGs.count) 张 JPG", "\(droppedJPEGs.count) JPGs imported")
    }

    private func acceptDrop(_ providers: [NSItemProvider]) -> Bool {
        let accepted = providers.filter { $0.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) }
        guard !accepted.isEmpty else { return false }
        for provider in accepted {
            provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
                let url: URL?
                if let data = item as? Data { url = URL(dataRepresentation: data, relativeTo: nil) }
                else { url = item as? URL }
                guard let url, ["jpg", "jpeg"].contains(url.pathExtension.lowercased()) else { return }
                DispatchQueue.main.async { droppedJPEGs = uniqueURLs(droppedJPEGs + [url]); results = [] }
            }
        }
        return true
    }

    @MainActor
    private func stopSearch() {
        activeSearchID = UUID()
        activeSearchWorker?.cancel()
        activeSearchWorker = nil
        searchTimeoutTask?.cancel()
        searchTimeoutTask = nil
        results = []
        message = text("已停止搜索。", "Search stopped.")
        isSearching = false
    }

    @MainActor
    private func search() {
        guard let searchFolder, !droppedJPEGs.isEmpty else { return }
        activeSearchWorker?.cancel()
        searchTimeoutTask?.cancel()
        let folder = searchFolder
        let jpegs = droppedJPEGs
        let searchID = UUID()
        activeSearchID = searchID
        isSearching = true
        message = nil
        let worker = Task.detached(priority: .userInitiated) {
            let scoped = folder.startAccessingSecurityScopedResource()
            defer { if scoped { folder.stopAccessingSecurityScopedResource() } }
            return try PhotoMatcher.matches(jpegs: jpegs, under: folder)
        }
        activeSearchWorker = worker
        searchTimeoutTask = Task {
            do {
                try await Task.sleep(for: .seconds(30))
            } catch {
                return
            }
            guard activeSearchID == searchID, isSearching else { return }
            activeSearchID = UUID()
            worker.cancel()
            results = jpegs.map { MatchResult(jpegURL: $0, rawURL: nil) }
            message = text("搜索超时，未找到匹配 RAW 文件。", "Search timed out. No matching RAW files were found.")
            activeSearchWorker = nil
            searchTimeoutTask = nil
            isSearching = false
        }
        Task { @MainActor in
            do {
                let found = try await worker.value
                guard activeSearchID == searchID else { return }
                results = found
                message = found.contains(where: { $0.rawURL != nil })
                    ? nil
                    : text("未找到匹配 RAW 文件。", "No matching RAW files were found.")
            } catch {
                guard activeSearchID == searchID else { return }
                message = text("搜索失败：\(error.localizedDescription)", "Search failed.")
            }
            guard activeSearchID == searchID else { return }
            searchTimeoutTask?.cancel()
            searchTimeoutTask = nil
            activeSearchWorker = nil
            isSearching = false
        }
    }

    @MainActor
    private func copyFound(to outputFolder: URL) {
        guard !isCopying else { return }
        let matches = results
        let progress = AsyncStream<CopyProgressUpdate>.makeStream(bufferingPolicy: .bufferingNewest(1))
        let continuation = progress.continuation
        isCopying = true
        copyProgress = 0
        copyStatus = text("正在完成第 1/\(foundCount) 个图片", "Copying image 1 of \(foundCount)")

        let worker = Task.detached(priority: .userInitiated) {
            let scoped = outputFolder.startAccessingSecurityScopedResource()
            defer {
                if scoped { outputFolder.stopAccessingSecurityScopedResource() }
                continuation.finish()
            }
            return try PhotoMatcher.copyMatches(matches, to: outputFolder) { completed, total in
                continuation.yield(CopyProgressUpdate(completed: completed, total: total))
            }
        }

        Task { @MainActor in
            for await update in progress.stream {
                guard isCopying, update.total > 0 else { continue }
                copyProgress = Double(update.completed) / Double(update.total)
                let current = min(update.completed + 1, update.total)
                copyStatus = text(
                    "正在完成第 \(current)/\(update.total) 个图片",
                    "Copying image \(current) of \(update.total)"
                )
            }
            do {
                let count = try await worker.value
                message = text("已复制 \(count) 个 RAW 文件", "Copied \(count) RAW files")
            } catch {
                message = text("复制失败：\(error.localizedDescription)", "Copy failed.")
            }
            isCopying = false
            copyStatus = ""
        }
    }

    private func revealFound() {
        let urls = results.compactMap(\.rawURL)
        guard !urls.isEmpty else { return }
        NSWorkspace.shared.activateFileViewerSelecting(urls)
    }

    private func applyAppearance() {
        switch appearanceMode {
        case .system:
            NSApp.appearance = nil
        case .light:
            NSApp.appearance = NSAppearance(named: .aqua)
        case .dark:
            NSApp.appearance = NSAppearance(named: .darkAqua)
        }
    }

    private func saveSearchFolder(_ result: Result<URL, Error>) {
        guard case let .success(url) = result else { return }
        let bookmark = (try? url.bookmarkData(options: .withSecurityScope, includingResourceValuesForKeys: nil, relativeTo: nil)) ?? Data()
        searchFolder = url
        searchBookmark = bookmark
    }

    private func updateLoginItem(_ enabled: Bool) {
        do {
            if enabled { try SMAppService.mainApp.register() }
            else { try SMAppService.mainApp.unregister() }
            message = enabled ? text("已设置为登录时启动", "Launch at Login enabled") : text("已关闭登录时启动", "Launch at Login disabled")
        } catch { launchAtLogin = false; message = text("启动项设置失败：\(error.localizedDescription)", "Could not update Login Item.") }
    }

    private func uniqueURLs(_ urls: [URL]) -> [URL] {
        var seen = Set<String>()
        return urls.filter { seen.insert($0.standardizedFileURL.path).inserted }
    }
}

private struct AboutView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var language: String
    @State private var iconTapCount = 0
    @State private var isShowingHint = false
    @State private var isShowingEasterEgg = false

    private func text(_ chinese: String, _ english: String) -> String {
        language == "en" ? english : chinese
    }

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 0) {
                VStack(alignment: .leading, spacing: 10) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(text("特别致谢", "Special Thanks"))
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(.secondary)
                        Text("idea from 高高辉")
                            .font(.system(size: 13, weight: .medium))
                    }
                    HStack(spacing: 14) {
                        Button(action: tapAppIcon) {
                            RawSeekIcon()
                                .frame(width: 54, height: 54)
                                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                                .scaleEffect(iconTapCount.isMultiple(of: 2) ? 1 : 0.9)
                                .animation(.spring(response: 0.22, dampingFraction: 0.42), value: iconTapCount)
                                .contentShape(RoundedRectangle(cornerRadius: 12))
                        }
                        .buttonStyle(.plain)
                        .help(text("点击图标", "Click the icon"))
                        .accessibilityLabel(text("RawSeek 图标", "RawSeek app icon"))
                        .sensoryFeedback(.selection, trigger: iconTapCount)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("RawSeek").font(.system(size: 21, weight: .semibold))
                            Text(text("版本 1.3", "Version 1.3")).font(.system(size: 12)).foregroundStyle(.secondary)
                        }
                    }
                    Text("Developed by HFar · Powered by Codex")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.secondary)
                    HStack(spacing: 10) {
                        Link(destination: URL(string: "https://github.com/HFarRay/RawSeek")!) {
                            Label(text("前往 GitHub 点个 Star", "Star RawSeek on GitHub"), systemImage: "star")
                        }
                        .buttonStyle(.bordered)
                        Link(destination: URL(string: "https://github.com/HFarRay/RawSeek/tree/main")!) {
                            Label(text("前往 GitHub 项目", "View RawSeek on GitHub"), systemImage: "chevron.left.forwardslash.chevron.right")
                        }
                        .buttonStyle(.bordered)
                    }
                }
                .padding(.bottom, 14)

                Divider()
                GeometryReader { geometry in
                    ScrollView {
                        VStack(alignment: .leading, spacing: 12) {
                            Text(text("更新日志", "Release Notes")).font(.system(size: 14, weight: .semibold))
                            Text("1.3 · \(text("增加了一个小彩蛋，优化软件流畅度，提高软件稳定性", "Added a small easter egg, improved performance and stability"))")
                                .font(.system(size: 12, weight: .medium))
                            Text("1.2 · \(text("复制进度与 JPG 缩略图", "Copy progress and JPG thumbnails"))")
                                .font(.system(size: 12, weight: .medium))
                            Text("1.1 · \(text("优化系统流畅度，提高系统稳定性", "Improved system responsiveness and stability"))")
                                .font(.system(size: 12, weight: .medium))
                            VStack(alignment: .leading, spacing: 8) {
                                changelogRow(text("拖入或选择 JPG，按文件名查找 RAW", "Drop or choose JPGs to find RAW files by filename"))
                                changelogRow(text("支持 RW2、ARW、CR2、CR3、NEF、DNG", "Supports RW2, ARW, CR2, CR3, NEF, and DNG"))
                                changelogRow(text("批量复制 RAW，或在访达中定位匹配文件", "Copy matched RAW files or reveal them in Finder"))
                                changelogRow(text("支持登录启动、程序坞图标与外观偏好", "Login Item, Dock icon, and appearance settings"))
                                changelogRow(text("优化系统流畅度，提高系统稳定性", "Improved system responsiveness and stability"))
                            }
                        }
                        .frame(width: geometry.size.width, alignment: .leading)
                    }
                    .scrollIndicators(.automatic)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)

                HStack {
                    NavigationLink {
                        UpdateView(language: $language)
                    } label: {
                        Label(text("检查更新", "Check for Updates"), systemImage: "arrow.down.circle")
                    }
                    .buttonStyle(.bordered)
                    Spacer()
                    Button(text("完成", "Done")) { dismiss() }
                        .buttonStyle(.borderedProminent)
                        .tint(RawSeekPalette.action)
                        .keyboardShortcut(.defaultAction)
                }
                .padding(.top, 12)
            }
            .padding(26)
            .frame(width: 520, height: 460)
            .background(Color(nsColor: .windowBackgroundColor))
        }
        .alert(text("还有几次点击就有惊喜", "A surprise is waiting"), isPresented: $isShowingHint) {
            Button(text("继续", "Continue"), role: .cancel) { }
        } message: {
            Text(text("再点击 5 次图标！", "Click the icon 5 more times!"))
        }
        .sheet(isPresented: $isShowingEasterEgg) {
            EasterEggView(language: language)
        }
    }

    private func tapAppIcon() {
        iconTapCount = min(iconTapCount + 1, 10)
        if iconTapCount == 5 {
            isShowingHint = true
        } else if iconTapCount == 10 {
            isShowingEasterEgg = true
        }
    }

    private func changelogRow(_ text: String) -> some View {
        Label(text, systemImage: "checkmark")
            .font(.system(size: 12))
            .foregroundStyle(.secondary)
    }
}

private struct EasterEggView: View {
    @Environment(\.dismiss) private var dismiss
    let language: String

    var body: some View {
        VStack(spacing: 14) {
            Image("RawSeek-Easter-Egg")
                .resizable()
                .scaledToFit()
                .clipShape(RoundedRectangle(cornerRadius: 10))
            Button(language == "en" ? "Close" : "关闭") { dismiss() }
                .buttonStyle(.borderedProminent)
                .tint(RawSeekPalette.action)
        }
        .padding(20)
        .frame(minWidth: 620, minHeight: 390)
    }
}

private struct UpdateView: View {
    @Environment(\.colorScheme) private var colorScheme
    @Binding var language: String
    @State private var isDropTargeted = false
    @State private var isChecking = false
    @State private var isConfirmingInstall = false
    @State private var status: String?
    @State private var candidate: UpdateCandidate?
    @State private var isInstalling = false

    private func text(_ chinese: String, _ english: String) -> String {
        language == "en" ? english : chinese
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 4) {
                Text(text("检查更新", "Check for Updates"))
                    .font(.system(size: 20, weight: .semibold))
                Text(text("当前版本 1.3", "Current version 1.3"))
                    .font(.system(size: 12)).foregroundStyle(.secondary)
            }
            VStack(spacing: 10) {
                Image(systemName: candidate == nil ? "shippingbox.and.arrow.backward" : "checkmark.seal.fill")
                    .font(.system(size: 27, weight: .light))
                    .foregroundStyle(RawSeekPalette.accent(for: colorScheme))
                Text(text("将 RawSeek DMG 拖到这里", "Drop a RawSeek DMG here"))
                    .font(.system(size: 14, weight: .medium))
                Text(text("检查镜像中的应用版本并准备更新", "Check the app version and prepare the update"))
                    .font(.system(size: 11)).foregroundStyle(.secondary)
                Button {
                    NSOpenPanel.openDMG(language: language) { inspect($0) }
                } label: {
                    Label(text("选择 DMG…", "Choose DMG…"), systemImage: "plus")
                        .font(.system(size: 12, weight: .medium))
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 170)
            .background(Color.primary.opacity(isDropTargeted ? 0.075 : 0.04), in: RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(isDropTargeted ? RawSeekPalette.accent(for: colorScheme).opacity(0.75) : Color.primary.opacity(0.12), style: StrokeStyle(lineWidth: 1, dash: [6, 5])))
            .onDrop(of: [.fileURL], isTargeted: $isDropTargeted, perform: acceptDMG)
            if isChecking {
                ProgressView(text("正在检查 DMG…", "Checking DMG…"))
                    .controlSize(.small)
            }
            if let candidate {
                Label(text("版本 \(candidate.version) 已准备安装", "Version \(candidate.version) is ready to install"), systemImage: "checkmark.circle.fill")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(RawSeekPalette.accent(for: colorScheme))
            }
            if let status {
                Text(status).font(.system(size: 11)).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
            HStack {
                Spacer()
                Button(text("安装并重启", "Install and Relaunch")) { isConfirmingInstall = true }
                    .buttonStyle(.borderedProminent)
                    .tint(RawSeekPalette.action)
                    .disabled(candidate == nil || isChecking)
            }
        }
        .padding(24)
        .frame(width: 480, height: 390)
        .navigationTitle(text("软件更新", "Software Update"))
        .onDisappear {
            if !isInstalling, let candidate {
                try? FileManager.default.removeItem(at: candidate.stagedApp)
            }
        }
        .confirmationDialog(
            text("替换当前 RawSeek 并重新启动？", "Replace the current RawSeek app and relaunch?"),
            isPresented: $isConfirmingInstall,
            titleVisibility: .visible
        ) {
            Button(text("安装并重启", "Install and Relaunch"), role: .destructive) { install() }
            Button(text("取消", "Cancel"), role: .cancel) {}
        }
    }

    private func acceptDMG(_ providers: [NSItemProvider]) -> Bool {
        guard let provider = providers.first(where: { $0.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) }) else { return false }
        provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
            let url: URL?
            if let data = item as? Data { url = URL(dataRepresentation: data, relativeTo: nil) }
            else { url = item as? URL }
            guard let url else { return }
            DispatchQueue.main.async { inspect(url) }
        }
        return true
    }

    @MainActor
    private func inspect(_ dmg: URL) {
        if let candidate { try? FileManager.default.removeItem(at: candidate.stagedApp) }
        candidate = nil
        status = nil
        isChecking = true
        Task {
            do {
                let result = try await Task.detached(priority: .userInitiated) {
                    try UpdateInstaller.stageDMG(dmg)
                }.value
                candidate = result
                status = text("已检查 DMG，版本 \(result.version) 可用于更新。", "DMG checked. Version \(result.version) is ready.")
            } catch let error as UpdateImportError {
                status = error.message(language: language)
            } catch {
                status = text("检查 DMG 失败。", "Could not inspect this DMG.")
            }
            isChecking = false
        }
    }

    @MainActor
    private func install() {
        guard let candidate else { return }
        do {
            try UpdateInstaller.scheduleInstall(stagedApp: candidate.stagedApp)
            isInstalling = true
            status = text("RawSeek 即将退出并安装更新。", "RawSeek will quit and install the update.")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { NSApp.terminate(nil) }
        } catch {
            status = text("无法启动更新安装。", "Could not start the update installer.")
        }
    }
}

private struct RawSeekIcon: View {
    var body: some View {
        Image(nsImage: NSApp.applicationIconImage)
            .resizable()
            .aspectRatio(contentMode: .fit)
    }
}

private enum RawSeekPalette {
    static let action = Color(red: 0.08, green: 0.34, blue: 0.22)

    static func accent(for colorScheme: ColorScheme) -> Color {
        colorScheme == .dark
            ? Color(red: 0.48, green: 0.82, blue: 0.61)
            : Color(red: 0.08, green: 0.38, blue: 0.25)
    }

    static func searchForeground(for colorScheme: ColorScheme) -> Color {
        colorScheme == .dark ? .white : action
    }

    static func searchBackground(for colorScheme: ColorScheme) -> Color {
        colorScheme == .dark ? action.opacity(0.84) : action.opacity(0.10)
    }
}

private struct CopyProgressUpdate: Sendable {
    let completed: Int
    let total: Int
}

private struct ImportedJPEGPreview: View {
    let url: URL

    @State private var thumbnail: NSImage?
    @State private var failedToLoad = false

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Group {
                if let thumbnail {
                    Image(nsImage: thumbnail)
                        .resizable()
                        .scaledToFill()
                } else if failedToLoad {
                    Image(systemName: "photo")
                        .font(.system(size: 20, weight: .light))
                        .foregroundStyle(.tertiary)
                } else {
                    ProgressView().controlSize(.small)
                }
            }
            .frame(width: 68, height: 68)
            .background(Color.primary.opacity(0.05))
            .clipShape(RoundedRectangle(cornerRadius: 6))

            Text(url.lastPathComponent)
                .font(.system(size: 10))
                .lineLimit(1)
                .frame(width: 82, alignment: .leading)
                .help(url.lastPathComponent)
        }
        .frame(width: 82, alignment: .leading)
        .task(id: url) {
            let request = QLThumbnailGenerator.Request(
                fileAt: url,
                size: CGSize(width: 136, height: 136),
                scale: NSScreen.main?.backingScaleFactor ?? 2,
                representationTypes: .thumbnail
            )
            do {
                thumbnail = try await QLThumbnailGenerator.shared.generateBestRepresentation(for: request).nsImage
            } catch {
                failedToLoad = true
            }
        }
    }
}

private struct SearchTaskbarProgressBar: View {
    let colorScheme: ColorScheme

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 60.0, paused: false)) { timeline in
            GeometryReader { geometry in
                let segmentWidth = max(20, geometry.size.width * 0.34)
                let travelDistance = max(0, geometry.size.width - segmentWidth)
                let phase = timeline.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 1.1) / 1.1

                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(Color.green.opacity(colorScheme == .dark ? 0.26 : 0.18))
                    RoundedRectangle(cornerRadius: 2)
                        .fill(Color(red: 0.16, green: 0.72, blue: 0.31))
                        .frame(width: segmentWidth)
                        .offset(x: travelDistance * phase)
                }
                .clipShape(RoundedRectangle(cornerRadius: 2))
            }
        }
        .frame(height: 4)
        .accessibilityLabel("Search progress")
    }
}

private struct UpdateCandidate: Sendable {
    let version: String
    let stagedApp: URL
}

private enum UpdateImportError: Error {
    case notDMG
    case mountFailed
    case appMissing
    case wrongApp
    case olderVersion
    case stagingFailed

    func message(language: String) -> String {
        let english = language == "en"
        switch self {
        case .notDMG: return english ? "Choose a .dmg disk image." : "请选择 .dmg 磁盘映像。"
        case .mountFailed: return english ? "Could not open this disk image." : "无法打开此磁盘映像。"
        case .appMissing: return english ? "RawSeek.app was not found in the DMG." : "DMG 中没有找到 RawSeek.app。"
        case .wrongApp: return english ? "This DMG does not contain a compatible RawSeek app." : "此 DMG 中的应用与 RawSeek 不兼容。"
        case .olderVersion: return english ? "This version is older than the installed version." : "此版本低于当前已安装版本。"
        case .stagingFailed: return english ? "Could not prepare the update." : "无法准备此更新。"
        }
    }
}

private enum FolderBookmarkResolver {
    static func resolve(_ data: Data) -> URL? {
        guard !data.isEmpty else { return nil }
        var stale = false
        return try? URL(
            resolvingBookmarkData: data,
            options: .withSecurityScope,
            relativeTo: nil,
            bookmarkDataIsStale: &stale
        )
    }
}

private enum UpdateInstaller {
    static func stageDMG(_ dmgURL: URL) throws -> UpdateCandidate {
        guard dmgURL.pathExtension.lowercased() == "dmg" else { throw UpdateImportError.notDMG }
        let scoped = dmgURL.startAccessingSecurityScopedResource()
        defer { if scoped { dmgURL.stopAccessingSecurityScopedResource() } }

        let plistData: Data
        do {
            plistData = try run("/usr/bin/hdiutil", ["attach", "-plist", "-nobrowse", "-readonly", dmgURL.path])
        } catch {
            throw UpdateImportError.mountFailed
        }
        guard let plist = try? PropertyListSerialization.propertyList(from: plistData, format: nil) as? [String: Any],
              let entities = plist["system-entities"] as? [[String: Any]],
              let entity = entities.first(where: { $0["mount-point"] is String }),
              let mountPath = entity["mount-point"] as? String else {
            throw UpdateImportError.mountFailed
        }
        let mountURL = URL(fileURLWithPath: mountPath, isDirectory: true)
        defer { _ = try? run("/usr/bin/hdiutil", ["detach", mountPath]) }

        let sourceApp = mountURL.appendingPathComponent("RawSeek.app", isDirectory: true)
        guard FileManager.default.fileExists(atPath: sourceApp.path) else { throw UpdateImportError.appMissing }
        guard let bundle = Bundle(url: sourceApp),
              bundle.object(forInfoDictionaryKey: "CFBundleIdentifier") as? String == "com.locally.rawseek",
              let version = bundle.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String else {
            throw UpdateImportError.wrongApp
        }
        let currentVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.3"
        guard version.compare(currentVersion, options: .numeric) != .orderedAscending else {
            throw UpdateImportError.olderVersion
        }

        let stagedApp = FileManager.default.temporaryDirectory
            .appendingPathComponent("RawSeek-Update-\(UUID().uuidString).app", isDirectory: true)
        do {
            try FileManager.default.copyItem(at: sourceApp, to: stagedApp)
        } catch {
            throw UpdateImportError.stagingFailed
        }
        return UpdateCandidate(version: version, stagedApp: stagedApp)
    }

    static func scheduleInstall(stagedApp: URL) throws {
        let appURL = Bundle.main.bundleURL.standardizedFileURL
        let parent = appURL.deletingLastPathComponent()
        let backupURL = parent.appendingPathComponent(".RawSeek-backup-\(UUID().uuidString).app")
        let scriptURL = FileManager.default.temporaryDirectory.appendingPathComponent("rawseek-update-\(UUID().uuidString).sh")
        let processID = ProcessInfo.processInfo.processIdentifier
        let script = """
        #!/bin/sh
        APP=\(shellQuote(appURL.path))
        STAGED=\(shellQuote(stagedApp.path))
        BACKUP=\(shellQuote(backupURL.path))
        APP_PID=\(processID)
        while /bin/kill -0 "$APP_PID" 2>/dev/null; do /bin/sleep 0.2; done
        /bin/mv "$APP" "$BACKUP" || exit 1
        if /usr/bin/ditto "$STAGED" "$APP"; then
            /bin/rm -rf "$BACKUP" "$STAGED"
            /usr/bin/open "$APP"
        else
            /bin/mv "$BACKUP" "$APP"
            exit 2
        fi
        /bin/rm -f "$0"
        """
        do {
            try script.write(to: scriptURL, atomically: true, encoding: .utf8)
            try FileManager.default.setAttributes([.posixPermissions: 0o700], ofItemAtPath: scriptURL.path)
            let process = Process()
            process.executableURL = URL(fileURLWithPath: "/bin/sh")
            process.arguments = [scriptURL.path]
            process.standardOutput = FileHandle.nullDevice
            process.standardError = FileHandle.nullDevice
            try process.run()
        } catch {
            throw UpdateImportError.stagingFailed
        }
    }

    private static func run(_ executable: String, _ arguments: [String]) throws -> Data {
        let process = Process()
        let output = Pipe()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments
        process.standardOutput = output
        process.standardError = output
        try process.run()
        let data = output.fileHandleForReading.readDataToEndOfFile()
        process.waitUntilExit()
        guard process.terminationStatus == 0 else { throw UpdateImportError.mountFailed }
        return data
    }

    private static func shellQuote(_ value: String) -> String {
        "'" + value.replacingOccurrences(of: "'", with: "'\\''") + "'"
    }
}

private struct GlassSurface<S: Shape>: ViewModifier {
    let shape: S

    @ViewBuilder
    func body(content: Content) -> some View {
        if #available(macOS 26.0, *) {
            content.glassEffect(.regular, in: shape)
        } else {
            content.background(.regularMaterial, in: shape)
        }
    }
}

private extension NSOpenPanel {
    static func openJPEGs(language: String, completion: @escaping ([URL]) -> Void) {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = false
        panel.allowedContentTypes = [.jpeg]
        panel.title = language == "en" ? "Choose JPG Photos" : "选择 JPG 照片"
        panel.begin { response in if response == .OK { completion(panel.urls) } }
    }

    static func openFolder(startingAt folder: URL?, language: String, completion: @escaping (URL) -> Void) {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.canCreateDirectories = true
        panel.directoryURL = folder
        panel.prompt = language == "en" ? "Copy to This Folder" : "复制到此文件夹"
        panel.begin { response in if response == .OK, let url = panel.url { completion(url) } }
    }

    static func openDMG(language: String, completion: @escaping (URL) -> Void) {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.allowedContentTypes = [UTType(filenameExtension: "dmg") ?? .data]
        panel.title = language == "en" ? "Choose RawSeek DMG" : "选择 RawSeek DMG"
        panel.begin { response in if response == .OK, let url = panel.url { completion(url) } }
    }
}
