# RawSeek 1.3 Release Notes

## English

- Added a small easter egg.
- Improved responsiveness and stability.
- Windows: dark appearance is the default for new installations.
- Windows: enlarged the donation QR-code view and updated the GitHub action label.
- Windows: retained the compact match/settings navigation and removed the update-import workflow.

## 中文

- 增加了一个小彩蛋。
- 优化软件流畅度，提高软件稳定性。
- Windows：首次启动默认使用深色外观。
- Windows：扩大捐赠二维码显示区域并更新 GitHub 操作按钮文案。
- Windows：采用配对/设置两级界面，并移除检查更新和更新导入功能。

## Release assets | 发布文件

- `RawSeek-1.3-macOS.dmg` — macOS installer image; macOS 14.0 or later.
- `RawSeek-1.3-macOS.zip` — macOS DMG with bilingual instructions.
- `RawSeek-1.3-Windows-x86.zip` — self-contained Windows x86 app and README.
- `RawSeek-1.3-Windows-x86.exe` — standalone Windows x86 executable.
- `RawSeek-1.3-Source.zip` — source for both macOS and Windows.
- `SHA256SUMS.txt` — SHA-256 checksums for release binaries and source archive.

## 发布文件

- `RawSeek-1.3-macOS.dmg`：macOS 安装镜像，支持 macOS 14.0 或更高版本。
- `RawSeek-1.3-macOS.zip`：包含 DMG 和双语说明的 macOS 压缩包。
- `RawSeek-1.3-Windows-x86.zip`：包含独立 Windows x86 程序和 README。
- `RawSeek-1.3-Windows-x86.exe`：独立 Windows x86 可执行文件。
- `RawSeek-1.3-Source.zip`：macOS 与 Windows 源码。
- `SHA256SUMS.txt`：发布程序和源码压缩包的 SHA-256 校验值。
