import Foundation

public struct MatchResult: Identifiable, Hashable, Sendable {
    public let id: UUID
    public let jpegURL: URL
    public let rawURL: URL?

    public init(jpegURL: URL, rawURL: URL?) {
        self.id = UUID()
        self.jpegURL = jpegURL
        self.rawURL = rawURL
    }
}

public enum PhotoMatcher {
    public static let rawExtensions: Set<String> = ["rw2", "arw", "cr2", "cr3", "nef", "dng"]

    public static func matches(jpegs: [URL], under root: URL) throws -> [MatchResult] {
        let keys = Set(jpegs.map { normalizedKey($0.deletingPathExtension().lastPathComponent) })
        let enumerator = FileManager.default.enumerator(
            at: root,
            includingPropertiesForKeys: [.isRegularFileKey],
            options: [.skipsHiddenFiles]
        )
        var candidates: [String: URL] = [:]
        while let url = enumerator?.nextObject() as? URL {
            try Task.checkCancellation()
            guard rawExtensions.contains(url.pathExtension.lowercased()) else { continue }
            let key = normalizedKey(url.deletingPathExtension().lastPathComponent)
            guard keys.contains(key), candidates[key] == nil else { continue }
            candidates[key] = url
        }
        return jpegs.map { jpeg in
            let key = normalizedKey(jpeg.deletingPathExtension().lastPathComponent)
            return MatchResult(jpegURL: jpeg, rawURL: candidates[key])
        }
    }

    public static func copyMatches(
        _ matches: [MatchResult],
        to destination: URL,
        onProgress: (@Sendable (_ completed: Int, _ total: Int) -> Void)? = nil
    ) throws -> Int {
        let raws = matches.compactMap(\.rawURL)
        let total = raws.count
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        var copied = 0
        onProgress?(0, total)
        for raw in raws {
            let target = destination.appendingPathComponent(raw.lastPathComponent)
            if FileManager.default.fileExists(atPath: target.path) {
                let stem = target.deletingPathExtension().lastPathComponent
                let ext = target.pathExtension
                var suffix = 2
                var alternative = destination.appendingPathComponent("\(stem) \(suffix).\(ext)")
                while FileManager.default.fileExists(atPath: alternative.path) {
                    suffix += 1
                    alternative = destination.appendingPathComponent("\(stem) \(suffix).\(ext)")
                }
                try FileManager.default.copyItem(at: raw, to: alternative)
            } else {
                try FileManager.default.copyItem(at: raw, to: target)
            }
            copied += 1
            onProgress?(copied, total)
        }
        return copied
    }

    private static func normalizedKey(_ value: String) -> String {
        value.precomposedStringWithCanonicalMapping.folding(
            options: [.caseInsensitive, .diacriticInsensitive], locale: .current
        )
    }
}
