using System.Windows;

namespace RawSeek.Windows;

public partial class App : System.Windows.Application
{
    public static bool IsEnglish { get; set; }
}
