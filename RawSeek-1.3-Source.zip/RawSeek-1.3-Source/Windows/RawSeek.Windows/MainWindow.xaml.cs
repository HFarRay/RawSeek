using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using DragEventArgs = System.Windows.DragEventArgs;
using Brush = System.Windows.Media.Brush;
using Application = System.Windows.Application;
using Brushes = System.Windows.Media.Brushes;
using Color = System.Windows.Media.Color;
using ColorConverter = System.Windows.Media.ColorConverter;
using DataFormats = System.Windows.DataFormats;
using DragDropEffects = System.Windows.DragDropEffects;
using Image = System.Windows.Controls.Image;
using MessageBox = System.Windows.MessageBox;
using Point = System.Windows.Point;

namespace RawSeek.Windows;

public partial class MainWindow : Window
{
    private static readonly HashSet<string> RawExtensions = new(StringComparer.OrdinalIgnoreCase)
        { ".rw2", ".arw", ".cr2", ".cr3", ".nef", ".dng" };
    private const string RegistryRoot = @"Software\RawSeek";
    private const string GithubUrl = "https://github.com/HFarRay/RawSeek";
    private readonly ObservableCollection<PhotoItem> _photos = new();
    private readonly ObservableCollection<MatchItem> _results = new();
    private readonly DispatcherTimer _progressTimer = new() { Interval = TimeSpan.FromMilliseconds(80) };
    private CancellationTokenSource? _searchCancellation;
    private int _easterEggClicks;
    private int _animatedProgress;
    private string _language = "zh";
    private string _appearance = "Dark";
    private string? _searchFolder;
    private bool _isSearching;
    private bool _isCopying;

    public ObservableCollection<MatchItem> Results => _results;

    public MainWindow()
    {
        InitializeComponent();
        DataContext = this;
        App.IsEnglish = _language == "en";
        ThumbnailItems.ItemsSource = _photos;
        ResultsList.ItemsSource = _results;
        _progressTimer.Tick += (_, _) => AnimateSearchProgress();
        LoadSettings();
        SelectAppearance();
        UpdateLanguage();
        ApplyTheme();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        Microsoft.Win32.SystemEvents.UserPreferenceChanged += SystemEvents_UserPreferenceChanged;
        ApplyTheme();
    }

    private void Window_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        _searchCancellation?.Cancel();
        Microsoft.Win32.SystemEvents.UserPreferenceChanged -= SystemEvents_UserPreferenceChanged;
    }

    private void LoadSettings()
    {
        using var key = Registry.CurrentUser.CreateSubKey(RegistryRoot);
        _language = key?.GetValue("Language", "zh")?.ToString() == "en" ? "en" : "zh";
        _appearance = key?.GetValue("Appearance", "Dark")?.ToString() ?? "Dark";
        var folder = key?.GetValue("SearchFolder")?.ToString();
        if (!string.IsNullOrWhiteSpace(folder) && Directory.Exists(folder)) _searchFolder = folder;
        if (_searchFolder is not null) FolderValue.Text = _searchFolder;
    }

    private void SaveSettings()
    {
        using var key = Registry.CurrentUser.CreateSubKey(RegistryRoot);
        key?.SetValue("Language", _language);
        key?.SetValue("Appearance", _appearance);
        if (_searchFolder is not null) key?.SetValue("SearchFolder", _searchFolder);
    }

    private void UpdateLanguage()
    {
        bool en = _language == "en";
        App.IsEnglish = en;
        SubtitleText.Text = en ? "JPG & camera RAW pairing" : "JPG 与相机 RAW 配对";
        SettingsButton.Content = en ? "Settings" : "设置";
        SettingsBackButton.Content = en ? "‹  Return to Match" : "‹  返回配对";
        SettingsHeading.Text = en ? "Settings" : "设置";
        AppearanceLabel.Text = en ? "Appearance" : "外观";
        SetAppearanceLabels(en);
        ImportHeading.Text = en ? "Import Photos" : "导入照片";
        DropTitle.Text = _photos.Count == 0 ? (en ? "Drop JPG photos here" : "将 JPG 照片拖到这里") : T($"已添加 {_photos.Count} 张 JPG 照片", $"{_photos.Count} JPG photos added");
        DropSubtitle.Text = en ? "Or choose multiple files" : "也可以点按选择多个文件";
        ChoosePhotosButton.Content = en ? "+  Choose JPGs" : "+  选择 JPG";
        ClearPhotosButton.Content = en ? "Clear" : "清除";
        ResultsHeading.Text = en ? "Match Results" : "匹配结果";
        FolderLabel.Text = en ? "RAW Search Folder" : "RAW 搜索目录";
        FolderValue.Text = _searchFolder ?? (en ? "Choose a folder…" : "选择文件夹…");
        SearchButton.Content = _isSearching ? T("■  停止搜索", "■  Stop Search") : T("⌕  搜索 RAW", "⌕  Search RAW");
        EmptyResultsText.Text = en ? "Matched files will appear here after searching" : "搜索后，匹配文件会显示在这里";
        RevealButton.Content = en ? "Show in Explorer" : "在资源管理器中显示";
        CopyButton.Content = _isCopying ? T("正在复制…", "Copying…") : T("复制到文件夹…", "Copy to Folder…");
        DonateHeading.Text = en ? "Support RawSeek" : "支持 RawSeek";
        DonateIntro.Text = en ? "Thank you for supporting RawSeek's continued development." : "感谢你支持 RawSeek 的持续维护。";
        WeChatTitle.Text = en ? "WeChat Pay" : "微信支付";
        AlipayTitle.Text = en ? "Alipay" : "支付宝";
        ThanksLabel.Text = en ? "Special Thanks" : "特别致谢";
        VersionText.Text = en ? "Version 1.3" : "版本 1.3";
        StarButton.Content = en ? "☆  Star on GitHub / Download Latest" : "☆  前往GitHub点个Star/下载新版本";
        ChangelogHeading.Text = en ? "Release Notes" : "更新日志";
        Changelog13.Text = en ? "1.3 · Added a small easter egg, improved responsiveness, and increased stability." : "1.3 · 增加了一个小彩蛋，优化软件流畅度，提高软件稳定性。";
        Changelog12.Text = en ? "1.2 · Copy progress and JPG thumbnails." : "1.2 · 复制进度与 JPG 缩略图。";
        Changelog11.Text = en ? "1.1 · Improved system responsiveness and stability." : "1.1 · 优化系统流畅度，提高系统稳定性。";
        FeaturesText.Text = en
            ? "✓ Drop or choose JPGs and match RAW by filename\n✓ Supports RW2, ARW, CR2, CR3, NEF, and DNG\n✓ Batch copy or reveal matches in Explorer\n✓ Choose system, light, or dark appearance"
            : "✓ 拖入 JPG，按文件名查找 RAW\n✓ 支持 RW2、ARW、CR2、CR3、NEF、DNG\n✓ 批量复制，或在资源管理器中定位\n✓ 跟随系统、浅色或深色外观";
        DonateButton.Content = en ? "Donate" : "捐赠支持";
        ChineseButton.Opacity = en ? 0.62 : 1;
        EnglishButton.Opacity = en ? 1 : 0.62;
        if (!_isSearching && !_isCopying && _results.Count == 0)
            StatusText.Text = _photos.Count == 0 ? T("等待导入 JPG", "Waiting for JPGs") : T($"已导入 {_photos.Count} 张 JPG", $"{_photos.Count} JPGs imported");
        UpdateResultSummary();
        ResultsList.Items.Refresh();
    }

    private string T(string chinese, string english) => _language == "en" ? english : chinese;

    private void SetAppearanceLabels(bool en)
    {
        if (AppearanceCombo.Items.Count != 3) return;
        ((ComboBoxItem)AppearanceCombo.Items[0]).Content = en ? "Follow system" : "跟随系统";
        ((ComboBoxItem)AppearanceCombo.Items[1]).Content = en ? "Light" : "浅色";
        ((ComboBoxItem)AppearanceCombo.Items[2]).Content = en ? "Dark" : "深色";
    }

    private void SelectAppearance()
    {
        AppearanceCombo.SelectedItem = AppearanceCombo.Items
            .OfType<ComboBoxItem>()
            .FirstOrDefault(item => string.Equals(item.Tag?.ToString(), _appearance, StringComparison.Ordinal));
    }

    private void ApplyTheme()
    {
        bool dark = _appearance == "Dark" || (_appearance == "System" && IsWindowsDarkMode());
        SetBrush("AppBackgroundBrush", dark ? "#202426" : "#F4F6F8");
        SetBrush("SurfaceBrush", dark ? "#292E30" : "#FFFFFF");
        SetBrush("SurfaceAltBrush", dark ? "#343A3D" : "#F0F3F5");
        SetBrush("TextBrush", dark ? "#F2F5F5" : "#202426");
        SetBrush("MutedBrush", dark ? "#B0BCBE" : "#667177");
        SetBrush("BorderBrush", dark ? "#444D50" : "#D9E0E3");
        SetBrush("AccentBrush", dark ? "#087A55" : "#167C67");
        SetBrush("AccentHoverBrush", dark ? "#0B8D62" : "#126B59");
        SetBrush("GreenBrush", dark ? "#4EC987" : "#28A36A");
        SetBrush("DangerBrush", dark ? "#E27578" : "#C83D43");
        Background = (Brush)FindResource("AppBackgroundBrush");
        Foreground = (Brush)FindResource("TextBrush");
    }

    private void SetBrush(string key, string color) => Application.Current.Resources[key] = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color));

    private static bool IsWindowsDarkMode()
    {
        using var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
        return Convert.ToInt32(key?.GetValue("AppsUseLightTheme", 1) ?? 1) == 0;
    }

    private void SystemEvents_UserPreferenceChanged(object sender, UserPreferenceChangedEventArgs e)
    {
        if (_appearance == "System") Dispatcher.BeginInvoke(ApplyTheme);
    }

    private void Chinese_Click(object sender, RoutedEventArgs e) { _language = "zh"; SaveSettings(); UpdateLanguage(); }
    private void English_Click(object sender, RoutedEventArgs e) { _language = "en"; SaveSettings(); UpdateLanguage(); }

    private void AppearanceCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (AppearanceCombo.SelectedItem is not ComboBoxItem selected || selected.Tag is null) return;
        _appearance = selected.Tag.ToString() ?? "System";
        SaveSettings();
        ApplyTheme();
    }

    private void Settings_Click(object sender, RoutedEventArgs e)
    {
        SearchView.Visibility = Visibility.Collapsed;
        SettingsView.Visibility = Visibility.Visible;
        SettingsButton.Visibility = Visibility.Collapsed;
        DonatePopup.IsOpen = false;
        SettingsBackButton.Focus();
    }

    private void SettingsBack_Click(object sender, RoutedEventArgs e)
    {
        DonatePopup.IsOpen = false;
        SettingsView.Visibility = Visibility.Collapsed;
        SearchView.Visibility = Visibility.Visible;
        SettingsButton.Visibility = Visibility.Visible;
    }

    private void Donate_Click(object sender, RoutedEventArgs e) => DonatePopup.IsOpen = !DonatePopup.IsOpen;

    private void Photos_DragEnter(object sender, DragEventArgs e) => SetPhotoDragState(e);
    private void Photos_DragOver(object sender, DragEventArgs e) => SetPhotoDragState(e);
    private void Photos_DragLeave(object sender, DragEventArgs e) => DropBorder.Opacity = 1;
    private void SetPhotoDragState(DragEventArgs e)
    {
        bool valid = e.Data.GetDataPresent(DataFormats.FileDrop) && ((string[])e.Data.GetData(DataFormats.FileDrop)!).Any(IsJpeg);
        e.Effects = valid ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;
        DropBorder.Opacity = valid ? 0.78 : 1;
    }

    private void Photos_Drop(object sender, DragEventArgs e)
    {
        DropBorder.Opacity = 1;
        if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;
        AddPhotos((string[])e.Data.GetData(DataFormats.FileDrop)!);
    }

    private static bool IsJpeg(string path) => File.Exists(path) && (Path.GetExtension(path).Equals(".jpg", StringComparison.OrdinalIgnoreCase) || Path.GetExtension(path).Equals(".jpeg", StringComparison.OrdinalIgnoreCase));

    private void ChoosePhotos_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog { Filter = "JPEG images|*.jpg;*.jpeg", Multiselect = true, Title = T("选择 JPG 照片", "Choose JPG Photos") };
        if (dialog.ShowDialog(this) == true) AddPhotos(dialog.FileNames);
    }

    private void AddPhotos(IEnumerable<string> paths)
    {
        var known = new HashSet<string>(_photos.Select(p => p.Path), StringComparer.OrdinalIgnoreCase);
        foreach (string path in paths.Where(IsJpeg))
            if (known.Add(Path.GetFullPath(path))) _photos.Add(new PhotoItem(path));
        _results.Clear();
        ThumbnailScroll.Visibility = _photos.Count == 0 ? Visibility.Collapsed : Visibility.Visible;
        ClearPhotosButton.Visibility = _photos.Count == 0 ? Visibility.Collapsed : Visibility.Visible;
        ResultsList.Visibility = Visibility.Collapsed;
        EmptyResultsText.Visibility = Visibility.Visible;
        UpdateLanguage();
    }

    private void ClearPhotos_Click(object sender, RoutedEventArgs e)
    {
        if (_isCopying) return;
        _photos.Clear(); _results.Clear();
        ThumbnailScroll.Visibility = Visibility.Collapsed; ClearPhotosButton.Visibility = Visibility.Collapsed;
        ResultsList.Visibility = Visibility.Collapsed; EmptyResultsText.Visibility = Visibility.Visible;
        RevealButton.IsEnabled = false; CopyButton.IsEnabled = false;
        UpdateLanguage();
    }

    private void ChooseSearchFolder_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFolderDialog { Title = T("选择 RAW 搜索目录", "Choose RAW Search Folder"), Multiselect = false };
        if (_searchFolder is not null) dialog.InitialDirectory = _searchFolder;
        if (dialog.ShowDialog(this) != true) return;
        _searchFolder = dialog.FolderName;
        FolderValue.Text = _searchFolder;
        Registry.CurrentUser.CreateSubKey(RegistryRoot)?.SetValue("SearchFolder", _searchFolder);
        _results.Clear(); ResultsList.Visibility = Visibility.Collapsed; EmptyResultsText.Visibility = Visibility.Visible;
        UpdateResultSummary();
    }

    private async void Search_Click(object sender, RoutedEventArgs e)
    {
        if (_isSearching) { _searchCancellation?.Cancel(); return; }
        if (_photos.Count == 0 || string.IsNullOrWhiteSpace(_searchFolder)) return;
        _searchCancellation = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        _isSearching = true;
        SearchButton.Background = (Brush)FindResource("DangerBrush");
        SearchButton.BorderBrush = (Brush)FindResource("DangerBrush");
        SearchButton.Foreground = Brushes.White;
        SearchButton.Content = T("■  停止搜索", "■  Stop Search");
        SearchProgressFill.Width = 2;
        _animatedProgress = 0;
        _progressTimer.Start();
        _results.Clear(); ResultsList.Visibility = Visibility.Collapsed; EmptyResultsText.Visibility = Visibility.Visible;
        SetBusyState();
        StatusText.Text = T("正在搜索 RAW 文件…", "Searching RAW files…");
        string[] jpegs = _photos.Select(p => p.Path).ToArray();
        string root = _searchFolder;
        var progress = new Progress<double>(value =>
        {
            _animatedProgress = Math.Max(_animatedProgress, (int)(Math.Clamp(value, 0, 0.94) * 100));
            UpdateSearchProgress();
        });
        try
        {
            var matches = await Task.Run(() => FindMatches(jpegs, root, progress, _searchCancellation.Token), _searchCancellation.Token);
            _results.Clear();
            foreach (var match in matches) _results.Add(match);
            RenderResults();
            int found = matches.Count(m => m.HasRaw);
            StatusText.Text = found == 0 ? T("未找到匹配 RAW 文件。", "No matching RAW files were found.") : T($"已找到 {found}/{matches.Count} 个 RAW 文件", $"Found {found} of {matches.Count} RAW files");
        }
        catch (OperationCanceledException)
        {
            StatusText.Text = _searchCancellation?.IsCancellationRequested == true && _searchCancellation.Token.IsCancellationRequested
                ? T("搜索已停止或超时，未找到文件。", "Search stopped or timed out; no files were found.")
                : T("搜索已停止。", "Search stopped.");
            _results.Clear(); RenderResults();
        }
        catch (Exception ex)
        {
            StatusText.Text = T($"搜索失败：{ex.Message}", $"Search failed: {ex.Message}");
        }
        finally
        {
            _progressTimer.Stop();
            SearchProgressFill.Width = 0;
            _isSearching = false;
            SearchButton.Background = (Brush)FindResource("AccentBrush");
            SearchButton.BorderBrush = (Brush)FindResource("AccentBrush");
            SearchButton.Foreground = Brushes.White;
            SearchButton.Content = T("⌕  搜索 RAW", "⌕  Search RAW");
            _searchCancellation?.Dispose(); _searchCancellation = null;
            SetBusyState();
            UpdateResultSummary();
        }
    }

    private static List<MatchItem> FindMatches(string[] jpegPaths, string root, IProgress<double> progress, CancellationToken token)
    {
        var keys = new HashSet<string>(jpegPaths.Select(path => Key(Path.GetFileNameWithoutExtension(path))), StringComparer.OrdinalIgnoreCase);
        var candidates = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        int visited = 0;
        foreach (string path in EnumerateFiles(root, token))
        {
            token.ThrowIfCancellationRequested();
            if (RawExtensions.Contains(Path.GetExtension(path)))
            {
                string key = Key(Path.GetFileNameWithoutExtension(path));
                if (keys.Contains(key) && !candidates.ContainsKey(key)) candidates.Add(key, path);
            }
            if (++visited % 128 == 0) progress.Report(Math.Min(0.92, visited / (visited + 2500.0)));
        }
        token.ThrowIfCancellationRequested();
        progress.Report(1);
        return jpegPaths.Select(jpeg =>
        {
            candidates.TryGetValue(Key(Path.GetFileNameWithoutExtension(jpeg)), out var raw);
            return new MatchItem(jpeg, raw);
        }).ToList();
    }

    private static IEnumerable<string> EnumerateFiles(string root, CancellationToken token)
    {
        var pending = new Stack<string>(); pending.Push(root);
        while (pending.Count > 0)
        {
            token.ThrowIfCancellationRequested();
            string folder = pending.Pop();
            string[] files;
            try { files = Directory.EnumerateFiles(folder).ToArray(); } catch { files = Array.Empty<string>(); }
            foreach (string file in files) { token.ThrowIfCancellationRequested(); yield return file; }
            string[] directories;
            try
            {
                directories = Directory.EnumerateDirectories(folder).ToArray();
            } catch { directories = Array.Empty<string>(); }
            foreach (string dir in directories)
                try { if ((File.GetAttributes(dir) & (FileAttributes.Hidden | FileAttributes.System | FileAttributes.ReparsePoint)) == 0) pending.Push(dir); } catch { }
        }
    }

    private static string Key(string value) => value.Normalize(NormalizationForm.FormKC).ToUpperInvariant();

    private void RenderResults()
    {
        ResultsList.Visibility = _results.Count == 0 ? Visibility.Collapsed : Visibility.Visible;
        EmptyResultsText.Visibility = _results.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        RevealButton.IsEnabled = _results.Any(r => r.HasRaw);
        CopyButton.IsEnabled = _results.Any(r => r.HasRaw) && !_isCopying;
        UpdateResultSummary();
    }

    private void UpdateResultSummary()
    {
        int found = _results.Count(r => r.HasRaw);
        ResultsCount.Text = _results.Count == 0 ? "" : T($"{found} / {_results.Count} 已找到", $"{found} / {_results.Count} found");
    }

    private void RevealResult_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as FrameworkElement)?.Tag is MatchItem match && match.RawPath is not null) RevealInExplorer(new[] { match.RawPath });
    }

    private void RevealAll_Click(object sender, RoutedEventArgs e) => RevealInExplorer(_results.Where(r => r.RawPath is not null).Select(r => r.RawPath!).ToArray());

    private static void RevealInExplorer(IReadOnlyCollection<string> paths)
    {
        foreach (var group in paths.Where(File.Exists).GroupBy(Path.GetDirectoryName))
        {
            if (group.Key is null) continue;
            try { ShellReveal.ShowSelected(group.Key, group.ToArray()); }
            catch { Process.Start(new ProcessStartInfo("explorer.exe", $"\"{group.Key}\"") { UseShellExecute = true }); }
        }
    }

    private async void Copy_Click(object sender, RoutedEventArgs e)
    {
        if (_isCopying) return;
        var dialog = new OpenFolderDialog { Title = T("选择 RAW 文件的目标文件夹", "Choose a destination folder for RAW files"), Multiselect = false };
        if (dialog.ShowDialog(this) != true) return;
        var raws = _results.Where(r => r.RawPath is not null).Select(r => r.RawPath!).ToArray();
        if (raws.Length == 0) return;
        _isCopying = true; CopyProgress.Visibility = Visibility.Visible; CopyProgress.Value = 0; CopyPercent.Text = "0%";
        CopyButton.Content = T($"正在完成第 1/{raws.Length} 个图片", $"Copying image 1 of {raws.Length}");
        SetBusyState();
        var progress = new Progress<int>(completed =>
        {
            CopyProgress.Value = completed * 100.0 / raws.Length;
            CopyPercent.Text = $"{completed * 100 / raws.Length}%";
            int current = Math.Min(completed + 1, raws.Length);
            CopyButton.Content = T($"正在完成第 {current}/{raws.Length} 个图片", $"Copying image {current} of {raws.Length}");
            StatusText.Text = T($"正在完成第 {current}/{raws.Length} 个图片", $"Copying image {current} of {raws.Length}");
        });
        try
        {
            int count = await Task.Run(() => CopyFiles(raws, dialog.FolderName, progress));
            StatusText.Text = T($"已复制 {count} 个 RAW 文件。", $"Copied {count} RAW files.");
        }
        catch (Exception ex) { StatusText.Text = T($"复制失败：{ex.Message}", $"Copy failed: {ex.Message}"); }
        finally { _isCopying = false; CopyProgress.Visibility = Visibility.Collapsed; CopyPercent.Text = ""; SetBusyState(); RenderResults(); }
    }

    private static int CopyFiles(string[] sources, string destination, IProgress<int> progress)
    {
        Directory.CreateDirectory(destination);
        int completed = 0;
        foreach (string source in sources)
        {
            string target = Path.Combine(destination, Path.GetFileName(source));
            if (File.Exists(target))
            {
                string stem = Path.GetFileNameWithoutExtension(target), ext = Path.GetExtension(target);
                int suffix = 2;
                do { target = Path.Combine(destination, $"{stem} {suffix++}{ext}"); } while (File.Exists(target));
            }
            File.Copy(source, target, false);
            progress.Report(++completed);
        }
        return completed;
    }

    private void SetBusyState()
    {
        bool busy = _isSearching || _isCopying;
        ChoosePhotosButton.IsEnabled = !busy;
        ClearPhotosButton.IsEnabled = !_isCopying;
        SearchFolderButton.IsEnabled = !_isCopying;
        RevealButton.IsEnabled = !busy && _results.Any(r => r.HasRaw);
        CopyButton.IsEnabled = !_isCopying && !_isSearching && _results.Any(r => r.HasRaw);
    }

    private void AnimateSearchProgress()
    {
        _animatedProgress = Math.Min(_animatedProgress + 1, 93);
        UpdateSearchProgress();
    }

    private void UpdateSearchProgress()
    {
        double width = Math.Max(1, SearchProgressTrack.ActualWidth - 26) * Math.Clamp(_animatedProgress / 100.0, 0, 0.94);
        SearchProgressFill.Width = width;
    }

    private void StarGithub_Click(object sender, RoutedEventArgs e) => OpenUrl(GithubUrl);
    private static void OpenUrl(string url) => Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });

    private void AboutIcon_Click(object sender, RoutedEventArgs e)
    {
        _easterEggClicks++;
        var scale = new ScaleTransform(0.88, 0.88);
        AboutIconButton.RenderTransformOrigin = new Point(0.5, 0.5);
        AboutIconButton.RenderTransform = scale;
        var animation = new DoubleAnimation(0.88, 1, TimeSpan.FromMilliseconds(180)) { EasingFunction = new BackEase { Amplitude = 0.25, EasingMode = EasingMode.EaseOut } };
        scale.BeginAnimation(ScaleTransform.ScaleXProperty, animation); scale.BeginAnimation(ScaleTransform.ScaleYProperty, animation);
        if (_easterEggClicks == 5) MessageBox.Show(this, T("再点击 5 次图标就有惊喜！", "Click the icon 5 more times for a surprise!"), T("还有几次点击就有惊喜", "A surprise is waiting"), MessageBoxButton.OK, MessageBoxImage.Information);
        if (_easterEggClicks >= 10)
        {
            _easterEggClicks = 0;
            var egg = new Window { Title = "RawSeek", Owner = this, Width = 720, Height = 520, MinWidth = 500, MinHeight = 380, WindowStartupLocation = WindowStartupLocation.CenterOwner, Background = (Brush)FindResource("AppBackgroundBrush") };
            egg.Content = new Image { Source = LoadImage("Assets/RawSeek-Easter-Egg.jpg"), Stretch = Stretch.Uniform, Margin = new Thickness(18) };
            egg.ShowDialog();
        }
    }

    private static BitmapImage LoadImage(string relativePath)
    {
        var image = new BitmapImage(); image.BeginInit(); image.UriSource = new Uri($"pack://application:,,,/{relativePath}"); image.CacheOption = BitmapCacheOption.OnLoad; image.EndInit(); image.Freeze(); return image;
    }
}

public sealed class PhotoItem
{
    public string Path { get; }
    public string Name => System.IO.Path.GetFileName(Path);
    public BitmapImage? Thumbnail { get; }
    public PhotoItem(string path)
    {
        Path = System.IO.Path.GetFullPath(path);
        try
        {
            var bitmap = new BitmapImage(); bitmap.BeginInit(); bitmap.UriSource = new Uri(Path); bitmap.DecodePixelWidth = 280; bitmap.CacheOption = BitmapCacheOption.OnLoad; bitmap.EndInit(); bitmap.Freeze(); Thumbnail = bitmap;
        }
        catch { Thumbnail = null; }
    }
}

public sealed class MatchItem
{
    public string JpegName { get; }
    public string? RawPath { get; }
    public string RawName => RawPath is null ? (RawSeek.Windows.App.IsEnglish ? "RAW file not found" : "未找到 RAW 文件") : System.IO.Path.GetFileName(RawPath);
    public string RawFolder => RawPath is null ? "" : System.IO.Path.GetDirectoryName(RawPath) ?? "";
    public bool HasRaw => RawPath is not null;
    public string StatusMark => HasRaw ? "✓" : "!";
    public Brush StatusBrush => HasRaw ? new SolidColorBrush(Color.FromRgb(40, 163, 106)) : Brushes.DarkOrange;
    public MatchItem(string jpeg, string? raw) { JpegName = System.IO.Path.GetFileName(jpeg); RawPath = raw; }
}

internal static class ShellReveal
{
    [System.Runtime.InteropServices.DllImport("shell32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
    private static extern int SHParseDisplayName(string name, IntPtr bindingContext, out IntPtr pidl, uint sfgaoIn, out uint psfgaoOut);
    [System.Runtime.InteropServices.DllImport("shell32.dll", ExactSpelling = true)]
    private static extern int SHOpenFolderAndSelectItems(IntPtr pidlFolder, uint cidl, [System.Runtime.InteropServices.In] IntPtr[] apidl, uint dwFlags);
    [System.Runtime.InteropServices.DllImport("shell32.dll", ExactSpelling = true)] private static extern IntPtr ILFindLastID(IntPtr pidl);
    [System.Runtime.InteropServices.DllImport("shell32.dll", ExactSpelling = true)] private static extern void ILFree(IntPtr pidl);

    public static void ShowSelected(string folder, IReadOnlyCollection<string> paths)
    {
        if (SHParseDisplayName(folder, IntPtr.Zero, out IntPtr folderPidl, 0, out _) != 0) throw new IOException("Could not open folder.");
        var absolute = new List<IntPtr>(); var children = new List<IntPtr>();
        try
        {
            foreach (string path in paths)
                if (SHParseDisplayName(path, IntPtr.Zero, out IntPtr pidl, 0, out _) == 0)
                {
                    absolute.Add(pidl);
                    children.Add(ILFindLastID(pidl));
                }
            int result = SHOpenFolderAndSelectItems(folderPidl, (uint)children.Count, children.ToArray(), 0x0001);
            if (result != 0) throw new IOException("Could not select files in Explorer.");
        }
        finally { foreach (var pidl in absolute) ILFree(pidl); ILFree(folderPidl); }
    }
}
