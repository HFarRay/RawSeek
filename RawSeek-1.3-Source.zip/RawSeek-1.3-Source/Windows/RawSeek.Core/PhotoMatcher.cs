using System.Text;

namespace RawSeek.Core;

public sealed record PhotoMatch(string JpegPath, string? RawPath)
{
    public bool HasRaw => RawPath is not null;
}

public static class PhotoMatcher
{
    public static readonly HashSet<string> RawExtensions = new(StringComparer.OrdinalIgnoreCase)
        { ".rw2", ".arw", ".cr2", ".cr3", ".nef", ".dng" };

    public static IReadOnlyList<PhotoMatch> Matches(
        IReadOnlyList<string> jpegPaths,
        string root,
        IProgress<double>? progress = null,
        CancellationToken cancellationToken = default)
    {
        var keys = new HashSet<string>(jpegPaths.Select(path => Key(Path.GetFileNameWithoutExtension(path))), StringComparer.OrdinalIgnoreCase);
        var candidates = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        int visited = 0;
        foreach (string path in EnumerateFiles(root, cancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (RawExtensions.Contains(Path.GetExtension(path)))
            {
                string key = Key(Path.GetFileNameWithoutExtension(path));
                if (keys.Contains(key) && !candidates.ContainsKey(key)) candidates.Add(key, path);
            }
            if (++visited % 128 == 0) progress?.Report(Math.Min(0.92, visited / (visited + 2500.0)));
        }
        cancellationToken.ThrowIfCancellationRequested();
        progress?.Report(1);
        return jpegPaths.Select(jpeg =>
        {
            candidates.TryGetValue(Key(Path.GetFileNameWithoutExtension(jpeg)), out var raw);
            return new PhotoMatch(jpeg, raw);
        }).ToArray();
    }

    public static int CopyMatches(IEnumerable<PhotoMatch> matches, string destination, IProgress<int>? progress = null)
    {
        Directory.CreateDirectory(destination);
        int total = matches.Count();
        int completed = 0;
        foreach (var match in matches.Where(match => match.RawPath is not null))
        {
            string source = match.RawPath!;
            string target = Path.Combine(destination, Path.GetFileName(source));
            if (File.Exists(target))
            {
                string stem = Path.GetFileNameWithoutExtension(target), ext = Path.GetExtension(target);
                int suffix = 2;
                do { target = Path.Combine(destination, $"{stem} {suffix++}{ext}"); } while (File.Exists(target));
            }
            File.Copy(source, target, false);
            progress?.Report(++completed);
        }
        return completed;
    }

    private static IEnumerable<string> EnumerateFiles(string root, CancellationToken token)
    {
        var pending = new Stack<string>(); pending.Push(root);
        while (pending.Count > 0)
        {
            token.ThrowIfCancellationRequested();
            string folder = pending.Pop();
            string[] files;
            try { files = Directory.EnumerateFiles(folder).ToArray(); } catch { files = Array.Empty<string>(); }
            foreach (string file in files) { token.ThrowIfCancellationRequested(); yield return file; }
            string[] directories;
            try { directories = Directory.EnumerateDirectories(folder).ToArray(); } catch { directories = Array.Empty<string>(); }
            foreach (string directory in directories)
                try { if ((File.GetAttributes(directory) & (FileAttributes.Hidden | FileAttributes.System | FileAttributes.ReparsePoint)) == 0) pending.Push(directory); } catch { }
        }
    }

    private static string Key(string value) => value.Normalize(NormalizationForm.FormKC).ToUpperInvariant();
}
