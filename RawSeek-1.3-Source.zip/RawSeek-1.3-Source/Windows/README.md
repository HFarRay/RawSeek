# RawSeek for Windows

RawSeek matches JPG/JPEG photos to camera RAW files by filename. This self-contained 32-bit Windows app supports recursive search, match review, File Explorer reveal, and batch copy with progress.

RawSeek 按文件名为 JPG/JPEG 照片查找对应的相机 RAW 文件。此 Windows 32 位独立应用支持递归搜索、查看匹配结果、在文件资源管理器中定位，以及显示进度的批量复制。

## Features | 功能

- Drag and drop or select multiple JPG/JPEG files; imported photos show filenames and thumbnails.  
  支持拖拽或批量选择 JPG/JPEG，并显示照片文件名和缩略图。
- Search the selected folder and its subfolders. Matching ignores filename case and applies Unicode compatibility normalization.  
  搜索所选目录及其子文件夹；文件名匹配不区分大小写，并会进行 Unicode 兼容规范化。
- Supported RAW formats: **RW2, ARW, CR2, CR3, NEF, DNG**.  
  支持的 RAW 格式：**RW2、ARW、CR2、CR3、NEF、DNG**。
- View results, reveal individual or all matches in File Explorer, or copy matches to a chosen destination.  
  查看匹配结果、在文件资源管理器中显示单个或全部文件，或将文件复制到指定目录。
- Search progress, a Stop action, and per-file copy progress.  
  提供搜索进度、停止搜索操作和逐文件复制进度。
- Chinese and English interface; light, dark, and follow-system appearance.  
  提供中英文界面、浅色、深色及跟随系统外观。
- Compact About and donation views with release notes and payment QR codes.  
  设置页内含关于信息、更新日志和捐赠二维码。

## Requirements | 系统要求

- Windows 10 or later, x86 or x64. The application itself is published as x86.  
  Windows 10 或更高版本，支持 x86 或 x64 系统；应用程序本身为 x86 构建。
- No separate .NET runtime installation is required for the published package.  
  使用已发布的程序包时，无需另行安装 .NET 运行时。

## Download and install | 下载与安装

1. Download `RawSeek-1.3-Windows-x86.zip` from [GitHub Releases](https://github.com/HFarRay/RawSeek/releases/latest).  
   从 [GitHub Releases](https://github.com/HFarRay/RawSeek/releases/latest) 下载 `RawSeek-1.3-Windows-x86.zip`。
2. Extract the ZIP file to a folder.  
   将 ZIP 文件解压到一个文件夹。
3. Run `RawSeek.exe`. No installer is required.  
   运行 `RawSeek.exe`，无需安装程序。

## Quick start | 快速开始

1. On the matching screen, drag JPG/JPEG files into the drop area or choose them with **Choose JPGs**. Review imported names and thumbnails.  
   在配对界面将 JPG/JPEG 拖入导入区域，或点按 **选择 JPG**；检查导入的文件名和缩略图。
2. Choose the folder that contains the camera RAW files. RawSeek searches its subfolders too.  
   选择相机 RAW 文件所在目录；RawSeek 也会搜索其子文件夹。
3. Select **Search RAW**. The folder control shows search progress; the search button becomes a red **Stop Search** action while a scan is running.  
   点按 **搜索 RAW**。目录控件会显示搜索进度；搜索时按钮会变为红色的 **停止搜索** 操作。
4. Review the match list. Use **Show in Explorer** to reveal matches or **Copy to Folder** to choose a destination and copy them.  
   查看匹配列表。使用 **在资源管理器中显示** 定位文件，或使用 **复制到文件夹** 选择目标目录并复制。

Search compares the filename without its extension. If multiple files with the same name exist in the destination, RawSeek keeps existing files and adds a numeric suffix to the new copy (for example, `IMG_0001 2.RW2`).

搜索时会比较不含扩展名的文件名。如果目标文件夹已有同名文件，RawSeek 会保留原文件，并为新副本添加数字后缀（例如 `IMG_0001 2.RW2`）。

## Settings and navigation | 设置与导航

- The app opens directly to the photo-matching screen. The **Settings** button sits beside the language controls at the top.  
  应用启动后直接进入照片配对界面；页首语言控件旁的 **设置** 按钮可打开设置页面。
- New installations default to dark appearance. A previously saved appearance choice is retained. Choose **Follow system**, **Light**, or **Dark** in Settings.  
  首次启动默认使用深色外观；已有的外观选择会保留。可在设置中选择 **跟随系统**、**浅色** 或 **深色**。
- Use the emoji flag buttons to switch Chinese and English.  
  使用页首的国旗 Emoji 按钮切换中文和英文。
- Settings includes About information, release notes, and a **Donate** button. Select **Return to Match** to go back to the pairing screen.  
  设置页面包含关于信息、更新日志和 **捐赠支持** 按钮；点按 **返回配对** 可回到配对界面。

## Troubleshooting | 常见问题

- **No match found:** confirm the RAW folder is selected and that the JPG and RAW filenames share the same name before their extensions.  
  **未找到匹配项：** 确认已选择 RAW 搜索目录，并检查 JPG 与 RAW 的扩展名前文件名是否相同。
- **A folder cannot be searched:** verify that the current Windows account can read that folder and its contents.  
  **目录无法搜索：** 检查当前 Windows 账户是否有权限读取该目录及其内容。
- **Copy did not replace an existing file:** this is intentional; the existing file is preserved and the new copy receives a numbered suffix.  
  **复制没有覆盖同名文件：** 这是预期行为；原文件会保留，新副本会添加数字后缀。

## Build and test | 构建与测试

Requirements: .NET 8 SDK. Run the core test suite and publish a self-contained x86 build from the repository root:

依赖：.NET 8 SDK。在仓库根目录运行核心测试并发布独立 x86 版本：

```sh
dotnet run --project Windows/RawSeek.Core.Tests/RawSeek.Core.Tests.csproj
dotnet publish Windows/RawSeek.Windows/RawSeek.Windows.csproj -c Release -r win-x86 --self-contained true -p:EnableWindowsTargeting=true -o outputs/windows-x86
```

On Windows PowerShell, `Windows/publish-windows.ps1` publishes the app and creates the ZIP package. The icon-generation scripts are only needed when regenerating the icon assets.

在 Windows PowerShell 中运行 `Windows/publish-windows.ps1` 可发布程序并生成 ZIP。仅在需要重新生成图标资源时才需要运行图标生成脚本。

## Release notes | 更新日志

### 1.3

- Added a small easter egg; improved responsiveness and stability.  
  增加了一个小彩蛋，优化软件流畅度，提高软件稳定性。
- Defaulted new installations to dark appearance; enlarged the donation QR-code view and updated the GitHub action label.  
  首次启动默认深色外观；扩大捐赠二维码显示区域并更新 GitHub 操作按钮文案。

### 1.2

- Added copy progress and imported JPG thumbnails.  
  增加复制进度和 JPG 缩略图。

### 1.1

- Improved system responsiveness and stability.  
  优化系统流畅度，提高系统稳定性。

## Project | 项目

- Repository | 仓库: [github.com/HFarRay/RawSeek](https://github.com/HFarRay/RawSeek)
- Latest release | 最新版本: [GitHub Releases](https://github.com/HFarRay/RawSeek/releases/latest)
- Version | 版本: **1.3**
- Developed by HFar, powered by Codex. | Developed by HFar, powered by Codex.
