using RawSeek.Core;

static void Check(bool condition, string message)
{
    if (!condition) throw new InvalidOperationException(message);
    Console.WriteLine($"PASS {message}");
}

string root = Path.Combine(Path.GetTempPath(), $"RawSeek-test-{Guid.NewGuid():N}");
string source = Path.Combine(root, "source");
string nested = Path.Combine(source, "nested");
string destination = Path.Combine(root, "destination");
Directory.CreateDirectory(nested);
try
{
    string rawOne = Path.Combine(nested, "IMG_0001.RW2");
    string rawTwo = Path.Combine(source, "img_0002.arw");
    File.WriteAllText(rawOne, "raw-1");
    File.WriteAllText(rawTwo, "raw-2");
    File.WriteAllText(Path.Combine(source, "IMG_0003.jpg"), "not raw");
    string[] jpegs = { "IMG_0001.JPG", "IMG_0002.jpeg", "IMG_0003.jpg", "IMG_0004.jpg" };
    var reports = new List<double>();
    var matches = PhotoMatcher.Matches(jpegs, source, new InlineProgress<double>(reports.Add));
    Check(matches.Count == 4 && matches[0].RawPath == rawOne && matches[1].RawPath == rawTwo, "recursive case-insensitive RAW matching");
    Check(!matches[2].HasRaw && !matches[3].HasRaw, "unsupported and missing files remain unmatched");
    Check(PhotoMatcher.RawExtensions.SetEquals(new[] { ".rw2", ".arw", ".cr2", ".cr3", ".nef", ".dng" }), "all supported RAW extensions");
    Directory.CreateDirectory(destination);
    File.WriteAllText(Path.Combine(destination, "IMG_0001.RW2"), "existing");
    var copied = new List<int>();
    int count = PhotoMatcher.CopyMatches(matches, destination, new InlineProgress<int>(copied.Add));
    Check(count == 2 && File.ReadAllText(Path.Combine(destination, "IMG_0001 2.RW2")) == "raw-1", "copy progress and collision-safe names");
    Check(copied.SequenceEqual(new[] { 1, 2 }), "copy progress reports each completed item");
    using var cancellation = new CancellationTokenSource(); cancellation.Cancel();
    bool cancelled = false;
    try { PhotoMatcher.Matches(jpegs, source, cancellationToken: cancellation.Token); }
    catch (OperationCanceledException) { cancelled = true; }
    Check(cancelled, "search cancellation");
}
finally { Directory.Delete(root, true); }

sealed class InlineProgress<T>(Action<T> callback) : IProgress<T>
{
    public void Report(T value) => callback(value);
}
