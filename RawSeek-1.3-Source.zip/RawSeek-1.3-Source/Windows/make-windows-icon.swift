import AppKit
import Foundation

guard CommandLine.arguments.count == 3 else {
    fatalError("Usage: swift make-windows-icon.swift input.png output.ico")
}

let inputURL = URL(fileURLWithPath: CommandLine.arguments[1])
let outputURL = URL(fileURLWithPath: CommandLine.arguments[2])
guard let source = NSImage(contentsOf: inputURL) else { fatalError("Could not load icon source") }
let sizes = [16, 24, 32, 48, 64, 128, 256]
var pngImages: [Data] = []

for size in sizes {
    guard let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: size, pixelsHigh: size,
        bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false,
        colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0) else {
        fatalError("Could not create icon bitmap")
    }
    NSGraphicsContext.saveGraphicsState()
    NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: bitmap)
    NSGraphicsContext.current?.imageInterpolation = .high
    source.draw(in: NSRect(x: 0, y: 0, width: size, height: size), from: .zero, operation: .copy, fraction: 1)
    NSGraphicsContext.restoreGraphicsState()
    guard let png = bitmap.representation(using: .png, properties: [:]) else { fatalError("Could not encode icon PNG") }
    pngImages.append(png)
}

func append16(_ value: UInt16, to data: inout Data) {
    data.append(UInt8(value & 0xff)); data.append(UInt8((value >> 8) & 0xff))
}
func append32(_ value: UInt32, to data: inout Data) {
    append16(UInt16(value & 0xffff), to: &data); append16(UInt16((value >> 16) & 0xffff), to: &data)
}

var ico = Data()
append16(0, to: &ico); append16(1, to: &ico); append16(UInt16(sizes.count), to: &ico)
var offset = UInt32(6 + sizes.count * 16)
for (size, png) in zip(sizes, pngImages) {
    ico.append(UInt8(size == 256 ? 0 : size)); ico.append(UInt8(size == 256 ? 0 : size))
    ico.append(0); ico.append(0)
    append16(1, to: &ico); append16(32, to: &ico)
    append32(UInt32(png.count), to: &ico); append32(offset, to: &ico)
    offset += UInt32(png.count)
}
pngImages.forEach { ico.append($0) }
try ico.write(to: outputURL, options: .atomic)
print("Created \(outputURL.path) with \(sizes.count) resolutions")
