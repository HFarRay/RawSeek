import AppKit
import CoreGraphics
import Foundation

guard CommandLine.arguments.count == 3 else {
    fatalError("Usage: swift prepare-windows-icon.swift input.png output.png")
}

let inputURL = URL(fileURLWithPath: CommandLine.arguments[1])
let outputURL = URL(fileURLWithPath: CommandLine.arguments[2])
guard let image = NSImage(contentsOf: inputURL),
      let source = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
    fatalError("Could not load icon source")
}

let width = source.width
let height = source.height
let pixelCount = width * height
var pixels = [UInt8](repeating: 0, count: pixelCount * 4)
let colorSpace = CGColorSpaceCreateDeviceRGB()
let bitmapInfo = CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue
pixels.withUnsafeMutableBytes { bytes in
    guard let context = CGContext(data: bytes.baseAddress, width: width, height: height,
                                  bitsPerComponent: 8, bytesPerRow: width * 4,
                                  space: colorSpace, bitmapInfo: bitmapInfo) else {
        fatalError("Could not decode icon pixels")
    }
    context.draw(source, in: CGRect(x: 0, y: 0, width: width, height: height))
}

func isBackdrop(_ index: Int) -> Bool {
    let offset = index * 4
    let red = Int(pixels[offset])
    let green = Int(pixels[offset + 1])
    let blue = Int(pixels[offset + 2])
    return red >= 247 && green >= 247 && blue >= 247 && max(red, green, blue) - min(red, green, blue) <= 12
}

var transparent = [UInt8](repeating: 0, count: pixelCount)
var queue = [Int]()
queue.reserveCapacity(pixelCount / 2)
func addIfBackdrop(_ index: Int) {
    if transparent[index] == 0 && isBackdrop(index) {
        transparent[index] = 1
        queue.append(index)
    }
}

for x in 0..<width {
    addIfBackdrop(x)
    addIfBackdrop((height - 1) * width + x)
}
for y in 0..<height {
    addIfBackdrop(y * width)
    addIfBackdrop(y * width + width - 1)
}

var cursor = 0
while cursor < queue.count {
    let index = queue[cursor]
    cursor += 1
    let x = index % width
    let y = index / width
    if x > 0 { addIfBackdrop(index - 1) }
    if x + 1 < width { addIfBackdrop(index + 1) }
    if y > 0 { addIfBackdrop(index - width) }
    if y + 1 < height { addIfBackdrop(index + width) }
}

var minX = width
var minY = height
var maxX = 0
var maxY = 0
let removedPixelCount = transparent.reduce(0) { $0 + Int($1) }
for index in 0..<pixelCount where transparent[index] == 0 {
    let x = index % width
    let y = index / width
    minX = min(minX, x)
    minY = min(minY, y)
    maxX = max(maxX, x)
    maxY = max(maxY, y)
}
guard minX <= maxX, minY <= maxY else { fatalError("Background removal left no subject") }

pixels.withUnsafeMutableBufferPointer { buffer in
    for index in 0..<pixelCount where transparent[index] == 1 {
        buffer[index * 4] = 0
        buffer[index * 4 + 1] = 0
        buffer[index * 4 + 2] = 0
        buffer[index * 4 + 3] = 0
    }
}
let cutoutData = Data(pixels)
guard let cutoutProvider = CGDataProvider(data: cutoutData as CFData),
      let cutout = CGImage(width: width, height: height, bitsPerComponent: 8,
                           bitsPerPixel: 32, bytesPerRow: width * 4,
                           space: colorSpace, bitmapInfo: CGBitmapInfo(rawValue: bitmapInfo),
                           provider: cutoutProvider, decode: nil, shouldInterpolate: true,
                           intent: .defaultIntent) else {
    fatalError("Could not create transparent cutout")
}

let canvasSize = 512
let margin = 8.0
let subject = CGRect(x: minX, y: minY, width: maxX - minX + 1, height: maxY - minY + 1)
let scale = min((Double(canvasSize) - margin * 2) / subject.width,
                (Double(canvasSize) - margin * 2) / subject.height)
let targetSize = CGSize(width: subject.width * scale, height: subject.height * scale)
let target = CGRect(x: (Double(canvasSize) - targetSize.width) / 2,
                    y: (Double(canvasSize) - targetSize.height) / 2,
                    width: targetSize.width, height: targetSize.height)
var output = [UInt8](repeating: 0, count: canvasSize * canvasSize * 4)
output.withUnsafeMutableBytes { bytes in
    guard let context = CGContext(data: bytes.baseAddress, width: canvasSize, height: canvasSize,
                                  bitsPerComponent: 8, bytesPerRow: canvasSize * 4,
                                  space: colorSpace, bitmapInfo: bitmapInfo) else {
        fatalError("Could not create icon canvas")
    }
    context.interpolationQuality = .high
    let rounded = CGPath(roundedRect: CGRect(x: 0, y: 0, width: canvasSize, height: canvasSize),
                         cornerWidth: 96, cornerHeight: 96, transform: nil)
    context.addPath(rounded)
    context.clip()
    context.draw(cutout, in: target, byTiling: false)
}

guard let outputImage = CGImage(width: canvasSize, height: canvasSize, bitsPerComponent: 8,
                                bitsPerPixel: 32, bytesPerRow: canvasSize * 4,
                                space: colorSpace, bitmapInfo: CGBitmapInfo(rawValue: bitmapInfo),
                                provider: CGDataProvider(data: Data(output) as CFData)!,
                                decode: nil, shouldInterpolate: true, intent: .defaultIntent),
      let bitmap = NSBitmapImageRep(cgImage: outputImage).representation(using: .png, properties: [:]) else {
    fatalError("Could not encode processed icon")
}
try bitmap.write(to: outputURL, options: .atomic)
print("Created rounded transparent icon at \(outputURL.path); removed \(removedPixelCount) background pixels; subject bounds \(minX),\(minY)-\(maxX),\(maxY)")
