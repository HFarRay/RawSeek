$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$project = Join-Path $PSScriptRoot "RawSeek.Windows\RawSeek.Windows.csproj"
$output = Join-Path $root "outputs\windows-x86"
$staging = Join-Path $env:TEMP "RawSeek-1.3-Windows-x86"
$zip = Join-Path $root "outputs\RawSeek-1.3-Windows-x86.zip"

dotnet publish $project -c Release -r win-x86 --self-contained true -p:EnableWindowsTargeting=true -o $output
if (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
New-Item -ItemType Directory -Path $staging | Out-Null
Copy-Item (Join-Path $output "RawSeek.exe") $staging
Copy-Item (Join-Path $PSScriptRoot "README.md") $staging
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path (Join-Path $staging "*") -DestinationPath $zip -CompressionLevel Optimal
Write-Host "Windows x86 app: $(Join-Path $output 'RawSeek.exe')"
Write-Host "Windows package: $zip"
