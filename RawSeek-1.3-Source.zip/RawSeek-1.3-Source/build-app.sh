#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
APP="$ROOT/outputs/RawSeek.app"
DMG="$ROOT/outputs/RawSeek.dmg"
MACOS_ZIP="$ROOT/outputs/RawSeek-1.3-macOS.zip"
SOURCE_ZIP="$ROOT/outputs/RawSeek-1.3-Source.zip"
STAGING="$(mktemp -d)"
trap 'rm -rf "$STAGING"' EXIT

cd "$ROOT"
swift test
swift build -c release
swift scripts/make-icon.swift
iconutil -c icns -o "$ROOT/Resources/RawSeek.icns" "$ROOT/Resources/RawSeek.iconset"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp .build/release/RawSeek "$APP/Contents/MacOS/RawSeek"
cp Info.plist "$APP/Contents/Info.plist"
cp "$ROOT/Resources/RawSeek.icns" "$APP/Contents/Resources/RawSeek.icns"
cp "$ROOT/Resources/RawSeek-Easter-Egg.jpg" "$APP/Contents/Resources/RawSeek-Easter-Egg.jpg"
cp "$ROOT/Resources/Donate-WeChat.jpg" "$ROOT/Resources/Donate-Alipay.jpg" "$APP/Contents/Resources/"
codesign --force --deep --sign - "$APP"
cp -R "$APP" "$STAGING/RawSeek.app"
ln -s /Applications "$STAGING/Applications"
hdiutil create -volname "RawSeek" -srcfolder "$STAGING" -ov -format UDZO "$DMG"
hdiutil verify "$DMG"
PACKAGE="$STAGING/RawSeek-1.3-macOS"
mkdir -p "$PACKAGE"
cp "$DMG" "$ROOT/README.md" "$PACKAGE/"
ditto -c -k --sequesterRsrc --keepParent "$PACKAGE" "$MACOS_ZIP"
(cd "$ROOT" && zip -q -r -X "$SOURCE_ZIP" Package.swift README.md Info.plist build-app.sh Sources Tests Resources scripts)
printf 'Built and verified: %s\nmacOS package: %s\nSource package: %s\n' "$DMG" "$MACOS_ZIP" "$SOURCE_ZIP"
