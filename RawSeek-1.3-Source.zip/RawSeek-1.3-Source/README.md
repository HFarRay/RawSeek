# RawSeek

**RawSeek pairs JPG/JPEG photos with their camera RAW files by filename.** It searches folders recursively, shows matching files, reveals them in Finder or File Explorer, and copies selected RAW files to another folder.

**RawSeek** 按文件名为 JPG/JPEG 照片查找对应的相机 RAW 文件。它支持递归搜索、显示匹配结果、在访达或文件资源管理器中定位文件，以及将匹配的 RAW 文件复制到其他文件夹。

## Features | 功能

- Import multiple JPG/JPEG photos by drag-and-drop or file picker; review filenames and thumbnails.  
  支持拖拽或文件选择器批量导入 JPG/JPEG，并查看文件名和缩略图。
- Match RAW files recursively by normalized, case-insensitive filename.  
  按经过规范化且不区分大小写的文件名递归匹配 RAW 文件。
- Search supports **RW2, ARW, CR2, CR3, NEF, and DNG**.  
  支持搜索 **RW2、ARW、CR2、CR3、NEF、DNG** 格式。
- Track search and copy progress; stop a running search.  
  显示搜索和复制进度，并可停止正在进行的搜索。
- Reveal matches in Finder/File Explorer or copy them to a chosen folder. Existing destination files are preserved; collisions receive a numbered filename.  
  可在访达/文件资源管理器中显示匹配文件，或复制到指定文件夹。目标文件不会被覆盖，重名文件会自动添加序号。
- Chinese and English interface, plus light, dark, or system appearance where supported.  
  提供中英文界面，以及浅色、深色或跟随系统外观选项（依平台而定）。

## Downloads | 下载

The latest release and platform-specific packages are published at [GitHub Releases](https://github.com/HFarRay/RawSeek/releases/latest).  
最新版本和各平台安装包发布于 [GitHub Releases](https://github.com/HFarRay/RawSeek/releases/latest)。

| Platform | Requirements | Package |
| --- | --- | --- |
| macOS | macOS 14.0 or later; Apple Silicon or Intel | `RawSeek-1.3-macOS.dmg` |
| Windows | Windows 10 or later; x86 or x64 | `RawSeek-1.3-Windows-x86.zip` |

| 平台 | 系统要求 | 安装包 |
| --- | --- | --- |
| macOS | macOS 14.0 或更高版本；Apple Silicon 或 Intel | `RawSeek-1.3-macOS.dmg` |
| Windows | Windows 10 或更高版本；x86 或 x64 | `RawSeek-1.3-Windows-x86.zip` |

### macOS installation | macOS 安装

1. Download and open `RawSeek-1.3-macOS.dmg`.  
   下载并打开 `RawSeek-1.3-macOS.dmg`。
2. Drag `RawSeek.app` to the Applications folder.  
   将 `RawSeek.app` 拖到“应用程序”文件夹。
3. Open RawSeek from Applications.  
   从“应用程序”中打开 RawSeek。

### Windows installation | Windows 安装

1. Download and extract `RawSeek-1.3-Windows-x86.zip`.  
   下载并解压 `RawSeek-1.3-Windows-x86.zip`。
2. Run `RawSeek.exe`. The package is self-contained and does not require a separate .NET runtime.  
   运行 `RawSeek.exe`。该程序为独立包，无需另行安装 .NET 运行时。

The Windows build is 32-bit and runs on supported 32-bit and 64-bit Windows systems. See [Windows/README.md](Windows/README.md) for Windows-specific instructions.  
Windows 版本为 32 位程序，可在支持的 32 位和 64 位 Windows 系统上运行。Windows 专用说明请见 [Windows/README.md](Windows/README.md)。

## Quick start | 快速开始

1. Drag JPG/JPEG files into the import area or choose files.  
   将 JPG/JPEG 文件拖入导入区域，或点按选择文件。
2. Choose the folder containing the RAW files. RawSeek also searches its subfolders.  
   选择 RAW 文件所在目录，RawSeek 也会搜索其子文件夹。
3. Select **Search RAW** and review the match results.  
   点按 **搜索 RAW** 并查看匹配结果。
4. Use **Show in Finder/Explorer** to locate files or **Copy to Folder** to copy them.  
   使用 **在访达/文件资源管理器中显示** 定位文件，或使用 **复制到文件夹**。

## Platform notes | 平台说明

### macOS

- Change language and appearance in Settings. The app also provides launch-at-login and taskbar-icon options.  
  在设置中切换语言和外观；应用还提供登录时启动和显示任务栏图标选项。
- About includes release notes, donation information, and the DMG update workflow.  
  关于页面包含更新日志、捐赠信息和 DMG 更新流程。

### Windows

- New installations default to dark appearance; a saved appearance preference is retained.  
  首次启动默认使用深色外观；已有外观偏好会保留。
- Open **Settings** beside the language controls for appearance, About, release notes, and donation. Use **Return to Match** to return to the pairing screen.  
  点按语言控件旁的 **设置** 可查看外观、关于、更新日志和捐赠；使用 **返回配对** 回到配对界面。
- Search can be stopped while running. Copy progress reports the current item and total.  
  搜索过程中可停止；复制时会显示当前图片序号和总数。

## Build from source | 从源码构建

### macOS

Requirements: Xcode Command Line Tools and Swift 6. Run tests with `swift test`; create the app and DMG with `./build-app.sh`.  
依赖：Xcode Command Line Tools 和 Swift 6。使用 `swift test` 运行测试，使用 `./build-app.sh` 构建应用和 DMG。

### Windows

Requirements: .NET 8 SDK. Run core tests and publish the x86 build:

```sh
dotnet run --project Windows/RawSeek.Core.Tests/RawSeek.Core.Tests.csproj
dotnet publish Windows/RawSeek.Windows/RawSeek.Windows.csproj -c Release -r win-x86 --self-contained true -p:EnableWindowsTargeting=true -o outputs/windows-x86
```

依赖：.NET 8 SDK。先运行核心测试，再发布 x86 版本：

```sh
dotnet run --project Windows/RawSeek.Core.Tests/RawSeek.Core.Tests.csproj
dotnet publish Windows/RawSeek.Windows/RawSeek.Windows.csproj -c Release -r win-x86 --self-contained true -p:EnableWindowsTargeting=true -o outputs/windows-x86
```

## Version 1.3 | 版本 1.3

- Added a small easter egg; improved responsiveness and stability.  
  增加了一个小彩蛋，优化软件流畅度，提高软件稳定性。
- Windows release: dark appearance is the clean-install default; the GitHub action and donation dialog have been refined.  
  Windows 版本：首次启动默认深色外观，完善 GitHub 操作入口和捐赠二维码弹窗。

## Project | 项目

- Repository: [github.com/HFarRay/RawSeek](https://github.com/HFarRay/RawSeek)
- Latest releases: [GitHub Releases](https://github.com/HFarRay/RawSeek/releases)
- Developed by HFar, powered by Codex.
