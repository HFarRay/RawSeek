import CoreGraphics
import Foundation
import ImageIO
import UniformTypeIdentifiers

let scriptURL = URL(fileURLWithPath: #filePath)
let root = scriptURL.deletingLastPathComponent().deletingLastPathComponent()
let sourceURL = root.appendingPathComponent("Resources/RawSeek-Icon-Source.png")
let iconsetURL = root.appendingPathComponent("Resources/RawSeek.iconset", isDirectory: true)

guard
    let source = CGImageSourceCreateWithURL(sourceURL as CFURL, nil),
    let sourceImage = CGImageSourceCreateImageAtIndex(source, 0, nil)
else {
    fatalError("Cannot read icon source at \(sourceURL.path)")
}

try FileManager.default.createDirectory(at: iconsetURL, withIntermediateDirectories: true)

let variants: [(Int, String)] = [
    (16, "icon_16x16.png"),
    (32, "icon_16x16@2x.png"),
    (32, "icon_32x32.png"),
    (64, "icon_32x32@2x.png"),
    (128, "icon_128x128.png"),
    (256, "icon_128x128@2x.png"),
    (256, "icon_256x256.png"),
    (512, "icon_256x256@2x.png"),
    (512, "icon_512x512.png"),
    (1024, "icon_512x512@2x.png")
]

for (size, name) in variants {
    var pixels = [UInt8](repeating: 0, count: size * size * 4)
    let image = pixels.withUnsafeMutableBytes { storage -> CGImage? in
        guard let context = CGContext(
            data: storage.baseAddress,
            width: size,
            height: size,
            bitsPerComponent: 8,
            bytesPerRow: size * 4,
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        ) else { return nil }

        context.interpolationQuality = .high
        context.draw(sourceImage, in: CGRect(x: 0, y: 0, width: size, height: size))

        return context.makeImage()
    }

    guard let image,
          let destination = CGImageDestinationCreateWithURL(
            iconsetURL.appendingPathComponent(name) as CFURL,
            UTType.png.identifier as CFString,
            1,
            nil
          ) else {
        fatalError("Cannot render icon variant \(name)")
    }
    CGImageDestinationAddImage(destination, image, nil)
    guard CGImageDestinationFinalize(destination) else {
        fatalError("Cannot write icon variant \(name)")
    }
}

print("Generated \(variants.count) square, full-bleed icon variants.")
