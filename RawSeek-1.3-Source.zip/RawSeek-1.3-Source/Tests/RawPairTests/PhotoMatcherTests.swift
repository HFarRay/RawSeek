import Foundation
import Testing
import RawPairCore

struct PhotoMatcherTests {
    @Test func findsSupportedRawExtensionsRecursivelyAndCaseInsensitively() throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        let nested = root.appendingPathComponent("nested", isDirectory: true)
        try FileManager.default.createDirectory(at: nested, withIntermediateDirectories: true)

        let extensions = ["rw2", "arw", "cr2", "cr3", "nef", "dng"]
        let jpegs = extensions.map { URL(fileURLWithPath: "/photos/IMG-\($0.uppercased()).JPG") }
        for ext in extensions {
            try Data([1]).write(to: nested.appendingPathComponent("img-\(ext).\(ext)"))
        }

        let results = try PhotoMatcher.matches(jpegs: jpegs, under: root)
        #expect(results.count == 6)
        #expect(results.allSatisfy { $0.rawURL != nil })
        #expect(Set(results.compactMap { $0.rawURL?.pathExtension.lowercased() }) == Set(extensions))
    }

    @Test func copyDoesNotOverwriteExistingRawFile() throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        let source = root.appendingPathComponent("IMG_1.CR3")
        let output = root.appendingPathComponent("output", isDirectory: true)
        try Data([1]).write(to: source)
        try FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
        try Data([2]).write(to: output.appendingPathComponent("IMG_1.CR3"))
        let match = MatchResult(jpegURL: URL(fileURLWithPath: "/photos/IMG_1.JPG"), rawURL: source)

        #expect(try PhotoMatcher.copyMatches([match], to: output) == 1)
        #expect(try Data(contentsOf: output.appendingPathComponent("IMG_1.CR3")) == Data([2]))
        #expect(try Data(contentsOf: output.appendingPathComponent("IMG_1 2.CR3")) == Data([1]))
    }

    @Test func copyReportsProgressForEachCompletedRawFile() throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        let output = root.appendingPathComponent("output", isDirectory: true)
        var matches: [MatchResult] = []
        for index in 1...2 {
            let raw = root.appendingPathComponent("IMG_\(index).NEF")
            try Data([UInt8(index)]).write(to: raw)
            matches.append(MatchResult(jpegURL: URL(fileURLWithPath: "/photos/IMG_\(index).JPG"), rawURL: raw))
        }
        let progress = ProgressValues()

        #expect(try PhotoMatcher.copyMatches(matches, to: output) { completed, total in
            progress.append(completed: completed, total: total)
        } == 2)
        #expect(progress.values == ["0/2", "1/2", "2/2"])
    }

    private func temporaryDirectory() throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }
}

private final class ProgressValues: @unchecked Sendable {
    private let lock = NSLock()
    private var storage: [String] = []

    var values: [String] {
        lock.lock()
        defer { lock.unlock() }
        return storage
    }

    func append(completed: Int, total: Int) {
        lock.lock()
        storage.append("\(completed)/\(total)")
        lock.unlock()
    }
}
