# RawSeek for macOS

RawSeek pairs JPG/JPEG photos with camera RAW files by filename. Import photos by drag-and-drop or file picker, search a folder and its subfolders, review thumbnails and matches, reveal files in Finder, or copy RAW files to another folder.

RawSeek 按文件名为 JPG/JPEG 照片查找相机 RAW 文件。支持拖拽或通过文件选择器导入照片、递归搜索目录、查看缩略图和匹配结果、在访达中定位文件，或将 RAW 文件复制到其他目录。

## Requirements | 系统要求

- macOS 14.0 or later. | macOS 14.0 或更高版本。
- Apple Silicon and Intel Macs. | 支持 Apple Silicon 和 Intel Mac。

## Install | 安装

1. Open `RawSeek-1.3-macOS.dmg`. | 打开 `RawSeek-1.3-macOS.dmg`。
2. Drag `RawSeek.app` to Applications. | 将 `RawSeek.app` 拖到“应用程序”文件夹。
3. Open RawSeek from Applications. | 从“应用程序”中打开 RawSeek。

## Use | 使用

1. Drop JPG/JPEG photos into the import area or choose multiple files. Filenames and thumbnails appear after import.  
   将 JPG/JPEG 照片拖入导入区域，或点按选择多个文件。导入后会显示文件名和缩略图。
2. Choose the RAW search folder and select **Search RAW**. The search includes subfolders.  
   选择 RAW 搜索目录并点按 **搜索 RAW**。搜索包含子文件夹。
3. Review matches, reveal files in Finder, or copy matches to a selected folder. Copy progress and current item count are shown.  
   查看匹配结果，在访达中定位文件，或复制到指定文件夹。复制时会显示进度和当前图片序号。

Supported RAW formats | 支持的 RAW 格式: **RW2, ARW, CR2, CR3, NEF, DNG**.

## Settings | 设置

- Use the flag buttons to switch Chinese and English. | 使用页首国旗按钮切换中文和英文。
- Choose System, Light, or Dark appearance. | 可选择跟随系统、浅色或深色外观。
- Configure Launch at Login and Show Taskbar Icon. | 可设置登录时启动和显示任务栏图标。
- About includes donation information and the DMG update workflow. | 关于页包含捐赠信息和 DMG 更新流程。

## Version 1.3 | 版本 1.3

- Added a small easter egg; improved responsiveness and stability.  
  增加了一个小彩蛋，优化软件流畅度，提高软件稳定性。

## Project | 项目

[GitHub Releases](https://github.com/HFarRay/RawSeek/releases/latest) · Developed by HFar, powered by Codex.  
[GitHub Releases](https://github.com/HFarRay/RawSeek/releases/latest) · Developed by HFar, powered by Codex.
